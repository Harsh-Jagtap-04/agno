# TPER AI Orchestration System

A complete, modular, and production-ready AI orchestration system implementing the **Think → Plan → Execute → Review (TPER)** workflow with OpenAI agents and dynamic tool loading.

## 🚀 Overview

This system uses OpenAI GPT-4 agents for reasoning and decision-making, integrates built-in tools dynamically, and supports extensibility through file-based tool modules.

### TPER Workflow

1. **🧠 Think Phase**: Analyzes input queries, breaks them into subtasks with dependencies
2. **📋 Plan Phase**: Generates step-by-step execution plans, maps subtasks to tools
3. **⚡ Execute Phase**: Dynamically executes plans using the tools manager
4. **🔍 Review Phase**: Evaluates results, decides to complete, replan, or retry

## 📁 Project Structure

\`\`\`
tper-orchestration-system/
├── .env                        # Environment variables
├── config.yaml                 # Configuration file
├── requirements.txt            # Python dependencies
├── main.py                     # Main entry point
├── agents/                     # AI agents for each TPER phase
│   ├── think_agent.py         # Task analysis agent
│   ├── plan_agent.py          # Planning agent
│   ├── execute_agent.py       # Execution agent
│   └── review_agent.py        # Review and decision agent
├── orchestrator/              # Main orchestration logic
│   ├── tper_orchestrator.py  # Main TPER workflow orchestrator
│   └── console_logger.py      # Rich console logging
└── tools/                     # Dynamic tool system
    ├── tools_manager.py       # Centralized tool discovery
    ├── builtins/              # Built-in tool wrappers
    │   ├── calculator_tool.py # Mathematical calculations
    │   ├── file_tool.py       # File operations
    │   ├── duckduckgo_tool.py # Web search
    │   ├── python_tool.py     # Code execution
    │   └── wikipedia_tool.py  # Wikipedia search
    └── mcp_servers/           # MCP server integrations
        └── github_mcp_server.py # GitHub integration
\`\`\`

## 🛠️ Setup Instructions

### 1. Install Dependencies

\`\`\`bash
pip install -r requirements.txt
\`\`\`

### 2. Environment Configuration

Create a \`.env\` file:

\`\`\`env
OPENAI_API_KEY=your_openai_api_key_here
GITHUB_TOKEN=your_github_token_here
\`\`\`

### 3. Run the System

\`\`\`bash
# Interactive mode (default)
python main.py

# Single query
python main.py --query "Analyze the latest AI developments"

# Batch processing
python main.py --batch queries.txt

# Direct orchestrator
python orchestrator/tper_orchestrator.py
\`\`\`

## 🤖 Agent Responsibilities

### ThinkAgent
- Analyzes user queries and breaks them into structured tasks
- Identifies dependencies, complexity, and required tools
- Outputs JSON task definitions with goals and success criteria

### PlanAgent
- Creates detailed step-by-step execution plans
- Maps each subtask to specific tools and parameters
- Provides risk assessment and fallback strategies

### ExecuteAgent
- Executes plans using the centralized tools manager
- Handles both built-in tools and external integrations
- Implements fallback mechanisms and error handling

### ReviewAgent
- Evaluates execution results against original user intent
- Decides whether to complete, retry, replan, or iterate
- Provides feedback for subsequent iterations

## 📊 Logging

The system provides comprehensive logging through the ConsoleLogger:

- **Phase Tracking**: Entry/exit logs for each TPER phase
- **Tool Execution**: Input/output logging for all tool calls
- **Decision Logging**: Clear visibility into retry and replan decisions
- **Iteration Tracking**: Progress through multiple TPER cycles
- **Rich Console Output**: Formatted panels and progress indicators

## 🔧 Adding New Tools Dynamically

### 1. Create Tool File

Add a Python file in the appropriate \`tools/\` subdirectory:

\`\`\`python
# tools/builtins/weather_tool.py
class WeatherTool:
    name = "weather_tool"
    description = "Fetches current weather information"
    
    def run(self, location: str) -> str:
        # Your tool implementation
        return f"Weather in {location}: Sunny, 25°C"
\`\`\`

### 2. Automatic Discovery

The \`tools_manager.py\` automatically discovers and loads new tools by:
- Scanning all Python files in tool directories
- Looking for classes with \`name\` and \`run\` attributes
- Making tools immediately available to agents

### 3. No Manual Registration Required

Tools become available to PlanAgent and ExecuteAgent immediately after file creation.

## ⚙️ Configuration

Customize behavior via \`config.yaml\`:

\`\`\`yaml
orchestrator:
  max_iterations: 5
  timeout_seconds: 300

agents:
  think:
    model: "gpt-4o"
    temperature: 0.7
  # ... other agent configurations

tools:
  cache_enabled: true
  cache_ttl: 3600
\`\`\`

## 🚀 Production Features

- **Error Handling**: Comprehensive exception handling and fallback mechanisms
- **Logging**: Detailed execution logs with rich console output
- **Caching**: Tool result caching to avoid redundant operations
- **Timeout Management**: Configurable timeouts for long-running operations
- **Iteration Limits**: Prevents infinite loops with configurable max iterations
- **Modular Design**: Easy to extend and modify individual components

## 📝 Example Usage

\`\`\`python
from orchestrator.tper_orchestrator import TPEROrchestrator

async def main():
    orchestrator = TPEROrchestrator()
    
    query = "Analyze the latest commits in a GitHub repository and create a summary report"
    
    result = await orchestrator.orchestrate(query)
    
    if result['status'] == 'completed':
        print("✅ Task completed successfully!")
    else:
        print(f"⚠️ Task status: {result['status']}")

# Run with: python -c "import asyncio; asyncio.run(main())"
\`\`\`

## 🔄 Extensibility

The system is designed for easy extension:

- **New Agents**: Add new agent types by implementing the same interface pattern
- **New Tools**: Drop Python files into tool directories for automatic discovery
- **New MCP Servers**: Add MCP server integrations in \`tools/mcp_servers/\`
- **Custom Workflows**: Extend the orchestrator for different workflow patterns

## 📈 Monitoring and Debugging

- Real-time console output with rich formatting
- Detailed log files for post-execution analysis
- Step-by-step execution tracking
- Tool input/output visibility
- Decision reasoning transparency

## 🎯 Key Features

- **Modular Architecture**: Clean separation of concerns
- **Dynamic Tool Loading**: File-based tool discovery system
- **Rich Logging**: Comprehensive execution tracking
- **Error Recovery**: Automatic retry and fallback mechanisms
- **Configuration Management**: YAML-based configuration
- **Production Ready**: Robust error handling and logging

This system provides a robust foundation for building complex AI workflows while maintaining modularity, extensibility, and production readiness.
