import json
import asyncio
from typing import Dict, Any, List
from openai import OpenAI
import os

class ExecuteAgent:
    """OpenAI-powered agent for executing plans using the tools manager."""
    
    def __init__(self, tools_manager, model_id: str = "gpt-4o", temperature: float = 0.3):
        self.tools_manager = tools_manager
        self.client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
        self.model_id = model_id
        self.temperature = temperature
        self.execution_log = []
        
        self.system_prompt = """
You are an execution agent. Your role is to execute plans step by step using available tools.

For each step:
1. Analyze the step requirements
2. Select the appropriate tool
3. Execute with proper parameters
4. Validate the output
5. Handle any errors with fallback strategies

Log all actions and results clearly.
"""
    
    async def execute_plan(self, execution_plan: Dict[str, Any]) -> Dict[str, Any]:
        """Execute the plan step by step."""
        results = {
            "execution_results": [],
            "success": True,
            "errors": [],
            "execution_log": []
        }
        
        for step in execution_plan.get("execution_plan", []):
            step_result = await self._execute_step(step)
            results["execution_results"].append(step_result)
            
            if not step_result["success"]:
                results["success"] = False
                results["errors"].append(step_result["error"])
                
                # Try fallback tools
                if step.get("fallback_tools"):
                    fallback_result = await self._try_fallback_tools(step)
                    if fallback_result["success"]:
                        results["execution_results"][-1] = fallback_result
                        results["success"] = True
        
        return results
    
    async def _execute_step(self, step: Dict[str, Any]) -> Dict[str, Any]:
        """Execute a single step."""
        step_id = step.get("step_id", "unknown")
        tool_name = step.get("tool", "")
        parameters = step.get("parameters", {})
        
        self.execution_log.append(f"Executing step {step_id} with tool {tool_name}")
        
        try:
            # Get tool from tools manager
            tool = self.tools_manager.get_tool(tool_name)
            
            if not tool:
                # Try built-in tools
                builtin_tools = self.tools_manager.get_agno_builtin_tools()
                if tool_name in builtin_tools:
                    # Simulate built-in tool execution
                    result = f"Executed built-in tool '{tool_name}' with parameters: {parameters}"
                else:
                    return {
                        "step_id": step_id,
                        "success": False,
                        "error": f"Tool {tool_name} not found",
                        "tool_used": tool_name
                    }
            else:
                # Execute the tool
                if hasattr(tool, 'run'):
                    if asyncio.iscoroutinefunction(tool.run):
                        result = await tool.run(**parameters)
                    else:
                        result = tool.run(**parameters)
                else:
                    result = f"Tool {tool_name} executed with parameters: {parameters}"
            
            return {
                "step_id": step_id,
                "success": True,
                "result": result,
                "tool_used": tool_name,
                "execution_time": "calculated"
            }
            
        except Exception as e:
            return {
                "step_id": step_id,
                "success": False,
                "error": str(e),
                "tool_used": tool_name
            }
    
    async def _try_fallback_tools(self, step: Dict[str, Any]) -> Dict[str, Any]:
        """Try fallback tools if primary tool fails."""
        for fallback_tool in step.get("fallback_tools", []):
            step_copy = step.copy()
            step_copy["tool"] = fallback_tool
            result = await self._execute_step(step_copy)
            if result["success"]:
                result["used_fallback"] = True
                return result
        
        return {
            "step_id": step.get("step_id", "unknown"),
            "success": False,
            "error": "All fallback tools failed",
            "used_fallback": True
        }
