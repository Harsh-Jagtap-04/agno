import json
from typing import Dict, Any, List
from openai import OpenAI
import os

class PlanAgent:
    """OpenAI-powered agent for creating detailed execution plans."""
    
    def __init__(self, model_id: str = "gpt-4o", temperature: float = 0.5):
        self.client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
        self.model_id = model_id
        self.temperature = temperature
        
        self.system_prompt = """
You are a strategic planning agent. Your role is to create detailed, step-by-step execution plans based on task analysis.

For each task breakdown, create:
1. Detailed execution steps with tool mappings
2. Risk mitigation strategies
3. Fallback plans for each step
4. Resource allocation and timing

Return your plan as structured JSON:
{
    "execution_plan": [
        {
            "step_id": "step_1",
            "description": "What to do",
            "tool": "tool_name",
            "parameters": {"param": "value"},
            "expected_output": "What to expect",
            "fallback_tools": ["alternative tools"],
            "success_criteria": "How to verify success",
            "estimated_duration": "time estimate"
        }
    ],
    "risk_mitigation": {
        "identified_risks": ["risk1", "risk2"],
        "mitigation_strategies": ["strategy1", "strategy2"]
    },
    "resource_requirements": ["tool1", "tool2"],
    "total_estimated_time": "overall time estimate"
}
"""
    
    async def create_plan(self, task_analysis: Dict[str, Any], available_tools: List[str]) -> Dict[str, Any]:
        """Create a detailed execution plan from task analysis."""
        
        prompt = f"""
Create a detailed execution plan based on this task analysis:

Task Analysis: {json.dumps(task_analysis, indent=2)}

Available Tools: {available_tools}

Create a comprehensive plan that maps each subtask to specific tools and provides detailed execution steps.
"""
        
        try:
            response = self.client.chat.completions.create(
                model=self.model_id,
                messages=[
                    {"role": "system", "content": self.system_prompt},
                    {"role": "user", "content": prompt}
                ],
                temperature=self.temperature
            )
            
            content = response.choices[0].message.content
            
            if "```json" in content:
                json_str = content.split("```json")[1].split("```")[0].strip()
            else:
                json_str = content
            
            return json.loads(json_str)
            
        except Exception as e:
            # Fallback plan structure
            return {
                "execution_plan": [
                    {
                        "step_id": "step_1",
                        "description": "Execute the task",
                        "tool": "general",
                        "parameters": {},
                        "expected_output": "Task completion",
                        "fallback_tools": [],
                        "success_criteria": "Task completed",
                        "estimated_duration": "unknown"
                    }
                ],
                "risk_mitigation": {
                    "identified_risks": [f"Plan creation failed: {str(e)}"],
                    "mitigation_strategies": ["Use fallback execution"]
                },
                "resource_requirements": available_tools,
                "total_estimated_time": "unknown"
            }
