import json
from typing import Dict, Any
from openai import OpenAI
import os

class ReviewAgent:
    """OpenAI-powered agent for reviewing execution results and making decisions."""
    
    def __init__(self, model_id: str = "gpt-4o", temperature: float = 0.6):
        self.client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
        self.model_id = model_id
        self.temperature = temperature
        
        self.system_prompt = """
You are a review and decision agent. Your role is to evaluate execution results against original user intent and decide next actions.

For each review:
1. Compare results with original goals and success criteria
2. Identify gaps or failures
3. Determine if the task is complete, needs retry, or requires replanning
4. Provide specific feedback for improvements

Return your review as structured JSON:
{
    "review_summary": "Overall assessment",
    "goal_achievement": {
        "completed_goals": ["list of completed goals"],
        "incomplete_goals": ["list of incomplete goals"],
        "achievement_percentage": 85
    },
    "quality_assessment": {
        "accuracy": "high|medium|low",
        "completeness": "high|medium|low",
        "efficiency": "high|medium|low"
    },
    "decision": "complete|retry|replan|iterate",
    "next_actions": ["specific actions to take"],
    "feedback_for_next_iteration": "Detailed feedback",
    "lessons_learned": ["key insights"]
}
"""
    
    async def review_execution(self,
                             original_query: str,
                             task_analysis: Dict[str, Any],
                             execution_results: Dict[str, Any]) -> Dict[str, Any]:
        """Review execution results and decide next actions."""
        
        prompt = f"""
Review the execution results against the original user query and task analysis:

Original Query: {original_query}

Task Analysis: {json.dumps(task_analysis, indent=2)}

Execution Results: {json.dumps(execution_results, indent=2)}

Provide a comprehensive review and decision for next steps.
"""
        
        try:
            response = self.client.chat.completions.create(
                model=self.model_id,
                messages=[
                    {"role": "system", "content": self.system_prompt},
                    {"role": "user", "content": prompt}
                ],
                temperature=self.temperature
            )
            
            content = response.choices[0].message.content
            
            if "```json" in content:
                json_str = content.split("```json")[1].split("```")[0].strip()
            else:
                json_str = content
            
            return json.loads(json_str)
            
        except Exception as e:
            # Fallback review structure
            success_rate = len([r for r in execution_results.get("execution_results", []) if r.get("success", False)])
            total_steps = len(execution_results.get("execution_results", []))
            
            return {
                "review_summary": f"Execution completed with {success_rate}/{total_steps} successful steps",
                "goal_achievement": {
                    "completed_goals": ["Partial completion"],
                    "incomplete_goals": ["Full verification needed"],
                    "achievement_percentage": (success_rate / max(total_steps, 1)) * 100
                },
                "quality_assessment": {
                    "accuracy": "medium",
                    "completeness": "medium",
                    "efficiency": "medium"
                },
                "decision": "complete" if success_rate == total_steps else "retry",
                "next_actions": ["Manual review needed"],
                "feedback_for_next_iteration": f"Review parsing failed: {str(e)}",
                "lessons_learned": ["Improve review parsing"]
            }
