import json
from typing import Dict, Any
from openai import OpenAI
import os

class ThinkAgent:
    """OpenAI-powered agent for analyzing and breaking down tasks."""
    
    def __init__(self, model_id: str = "gpt-4o", temperature: float = 0.7):
        self.client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
        self.model_id = model_id
        self.temperature = temperature
        
        self.system_prompt = """
You are a strategic thinking agent. Your role is to analyze user queries and break them down into structured, actionable tasks.

For each query, provide:
1. Analysis of the user's intent and goals
2. Breakdown into subtasks with dependencies
3. Risk assessment and complexity evaluation
4. Required tools and resources

Return your analysis as a structured JSON with the following format:
{
    "intent": "Clear description of user intent",
    "goals": ["List of specific goals"],
    "subtasks": [
        {
            "id": "task_1",
            "description": "Task description",
            "dependencies": ["list of dependency task IDs"],
            "complexity": "low|medium|high",
            "estimated_time": "time estimate",
            "required_tools": ["list of tools needed"]
        }
    ],
    "risks": ["List of potential risks or challenges"],
    "success_criteria": ["How to measure success"]
}
"""
    
    async def analyze(self, query: str, context: Dict[str, Any] = None) -> Dict[str, Any]:
        """Analyze the query and return structured task breakdown."""
        
        prompt = f"""
Analyze this user query and provide a structured breakdown:

Query: {query}

Context: {json.dumps(context or {}, indent=2)}

Provide your analysis in the specified JSON format.
"""
        
        try:
            response = self.client.chat.completions.create(
                model=self.model_id,
                messages=[
                    {"role": "system", "content": self.system_prompt},
                    {"role": "user", "content": prompt}
                ],
                temperature=self.temperature
            )
            
            content = response.choices[0].message.content
            
            # Extract JSON from response
            if "```json" in content:
                json_str = content.split("```json")[1].split("```")[0].strip()
            else:
                json_str = content
            
            return json.loads(json_str)
            
        except Exception as e:
            # Fallback structure if JSON parsing fails
            return {
                "intent": query,
                "goals": ["Complete the requested task"],
                "subtasks": [
                    {
                        "id": "task_1",
                        "description": query,
                        "dependencies": [],
                        "complexity": "medium",
                        "estimated_time": "unknown",
                        "required_tools": ["general"]
                    }
                ],
                "risks": [f"Analysis failed: {str(e)}"],
                "success_criteria": ["Task completion"]
            }
