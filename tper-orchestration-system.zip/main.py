#!/usr/bin/env python3
"""
TPER AI Orchestration System
Main entry point for the Think → Plan → Execute → Review workflow
"""

import asyncio
import sys
import os
from pathlib import Path

# Add the project root to Python path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from orchestrator.tper_orchestrator import TPEROrchestrator

async def interactive_mode():
    """Run the orchestrator in interactive mode."""
    orchestrator = TPEROrchestrator()
    
    print("🤖 TPER AI Orchestration System")
    print("=" * 50)
    print("Enter your queries below. Type 'quit' to exit.")
    print("=" * 50)
    
    while True:
        try:
            query = input("\n💭 Your query: ").strip()
            
            if query.lower() in ['quit', 'exit', 'q']:
                print("👋 Goodbye!")
                break
            
            if not query:
                print("Please enter a valid query.")
                continue
            
            print(f"\n🚀 Processing: {query}")
            result = await orchestrator.orchestrate(query)
            
            # Display summary
            print(f"\n📊 SUMMARY")
            print(f"Status: {result.get('status')}")
            print(f"Iterations: {result.get('iteration')}")
            
            if result.get('status') == 'completed':
                print("✅ Task completed successfully!")
                
                # Show key results
                if 'review_results' in result:
                    review = result['review_results']
                    achievement = review.get('goal_achievement', {})
                    print(f"Achievement: {achievement.get('achievement_percentage', 0)}%")
            else:
                print(f"⚠️ Task ended with status: {result.get('status')}")
                if 'error' in result:
                    print(f"Error: {result['error']}")
        
        except KeyboardInterrupt:
            print("\n👋 Goodbye!")
            break
        except Exception as e:
            print(f"❌ Error: {e}")

async def batch_mode(queries):
    """Run the orchestrator in batch mode with predefined queries."""
    orchestrator = TPEROrchestrator()
    
    results = []
    
    for i, query in enumerate(queries, 1):
        print(f"\n🔄 Processing query {i}/{len(queries)}: {query}")
        result = await orchestrator.orchestrate(query)
        results.append({
            "query": query,
            "result": result
        })
    
    # Summary report
    print("\n" + "=" * 60)
    print("📊 BATCH PROCESSING SUMMARY")
    print("=" * 60)
    
    for i, item in enumerate(results, 1):
        status = item["result"].get("status")
        iterations = item["result"].get("iteration", 0)
        print(f"{i}. {item['query'][:50]}...")
        print(f"   Status: {status} | Iterations: {iterations}")
    
    return results

def main():
    """Main entry point."""
    import argparse
    
    parser = argparse.ArgumentParser(description="TPER AI Orchestration System")
    parser.add_argument("--query", "-q", help="Single query to process")
    parser.add_argument("--batch", "-b", help="File containing queries (one per line)")
    parser.add_argument("--interactive", "-i", action="store_true", help="Run in interactive mode")
    
    args = parser.parse_args()
    
    if args.query:
        # Single query mode
        async def single_query():
            orchestrator = TPEROrchestrator()
            result = await orchestrator.orchestrate(args.query)
            
            print(f"\n📊 RESULT")
            print(f"Status: {result.get('status')}")
            print(f"Iterations: {result.get('iteration')}")
            
            if result.get('status') == 'completed':
                print("✅ Task completed successfully!")
            else:
                print(f"⚠️ Task ended with status: {result.get('status')}")
        
        asyncio.run(single_query())
    
    elif args.batch:
        # Batch mode
        if not os.path.exists(args.batch):
            print(f"❌ Batch file not found: {args.batch}")
            sys.exit(1)
        
        with open(args.batch, 'r') as f:
            queries = [line.strip() for line in f if line.strip()]
        
        if not queries:
            print("❌ No queries found in batch file")
            sys.exit(1)
        
        asyncio.run(batch_mode(queries))
    
    else:
        # Interactive mode (default)
        asyncio.run(interactive_mode())

if __name__ == "__main__":
    main()
