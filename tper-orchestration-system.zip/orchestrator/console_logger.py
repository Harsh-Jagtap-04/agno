import logging
import json
from datetime import datetime
from typing import Dict, Any

class ConsoleLogger:
    """Enhanced console logger for TPER orchestration."""
    
    def __init__(self):
        self.iteration_count = 0
        self.current_phase = None
        self.start_time = None
        
        # Setup logging
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler('tper_orchestrator.log'),
                logging.StreamHandler()
            ]
        )
        self.logger = logging.getLogger(__name__)
    
    def log_orchestrator_start(self, query: str):
        """Log the start of orchestration."""
        self.start_time = datetime.now()
        self.iteration_count = 0
        
        print("=" * 60)
        print("🚀 TPER ORCHESTRATOR STARTED")
        print("=" * 60)
        print(f"Query: {query}")
        print(f"Time: {self.start_time.strftime('%Y-%m-%d %H:%M:%S')}")
        print("=" * 60)
        
        self.logger.info(f"Orchestrator started with query: {query}")
    
    def log_iteration_start(self, iteration: int):
        """Log the start of a new iteration."""
        self.iteration_count = iteration
        
        print(f"\n🔄 STARTING ITERATION {iteration}")
        print("-" * 40)
        
        self.logger.info(f"Starting iteration {iteration}")
    
    def log_phase_start(self, phase: str, details: str = ""):
        """Log the start of a TPER phase."""
        self.current_phase = phase
        
        phase_icons = {
            "Think": "🧠",
            "Plan": "📋",
            "Execute": "⚡",
            "Review": "🔍"
        }
        
        icon = phase_icons.get(phase, "📌")
        
        print(f"\n{icon} {phase.upper()} PHASE - Iteration {self.iteration_count}")
        if details:
            print(f"Details: {details}")
        print("-" * 30)
        
        self.logger.info(f"Phase {phase} started in iteration {self.iteration_count}")
    
    def log_phase_result(self, phase: str, result: Dict[str, Any]):
        """Log the result of a TPER phase."""
        print(f"\n✅ {phase.upper()} PHASE COMPLETE")
        
        if isinstance(result, dict):
            # Print key information from result
            if phase == "Think" and "intent" in result:
                print(f"Intent: {result['intent']}")
                print(f"Goals: {len(result.get('goals', []))} identified")
                print(f"Subtasks: {len(result.get('subtasks', []))} created")
            elif phase == "Plan" and "execution_plan" in result:
                print(f"Steps: {len(result['execution_plan'])} planned")
                print(f"Estimated time: {result.get('total_estimated_time', 'unknown')}")
            elif phase == "Execute" and "execution_results" in result:
                success_count = sum(1 for r in result['execution_results'] if r.get('success'))
                total_count = len(result['execution_results'])
                print(f"Execution: {success_count}/{total_count} steps successful")
            elif phase == "Review" and "decision" in result:
                print(f"Decision: {result['decision']}")
                print(f"Achievement: {result.get('goal_achievement', {}).get('achievement_percentage', 0)}%")
        
        print("-" * 30)
        
        self.logger.info(f"Phase {phase} completed")
    
    def log_tool_execution(self, tool_name: str, input_data: Dict[str, Any], output_data: Any):
        """Log tool execution details."""
        print(f"🔧 Tool: {tool_name}")
        print(f"Input: {input_data}")
        output_str = str(output_data)[:200] + "..." if len(str(output_data)) > 200 else str(output_data)
        print(f"Output: {output_str}")
        
        self.logger.info(f"Tool {tool_name} executed successfully")
    
    def log_decision(self, decision: str, reasoning: str):
        """Log orchestrator decisions."""
        print(f"\n🎯 DECISION: {decision.upper()}")
        print(f"Reasoning: {reasoning}")
        print("-" * 30)
        
        self.logger.info(f"Decision made: {decision} - {reasoning}")
    
    def log_error(self, error: str, phase: str = None):
        """Log errors with context."""
        error_context = f" in {phase} phase" if phase else ""
        
        print(f"\n❌ ERROR{error_context.upper()}")
        print(f"Error: {error}")
        print("-" * 30)
        
        self.logger.error(f"Error{error_context}: {error}")
    
    def log_orchestrator_complete(self, final_result: Dict[str, Any]):
        """Log the completion of orchestration."""
        end_time = datetime.now()
        duration = end_time - self.start_time if self.start_time else "Unknown"
        
        print("\n" + "=" * 60)
        print("✅ TPER ORCHESTRATION COMPLETE")
        print("=" * 60)
        print(f"Iterations: {self.iteration_count}")
        print(f"Duration: {duration}")
        print(f"Final Status: {final_result.get('status', 'Unknown')}")
        print("=" * 60)
        
        self.logger.info(f"Orchestration completed after {self.iteration_count} iterations")
    
    def log_retry_attempt(self, attempt: int, max_attempts: int, reason: str):
        """Log retry attempts."""
        print(f"\n🔄 RETRY ATTEMPT {attempt}/{max_attempts}")
        print(f"Reason: {reason}")
        print("-" * 30)
        
        self.logger.warning(f"Retry attempt {attempt}/{max_attempts}: {reason}")
