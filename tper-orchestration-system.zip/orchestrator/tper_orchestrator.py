import asyncio
import yaml
from typing import Dict, Any, Optional
from pathlib import Path

from agents.think_agent import ThinkAgent
from agents.plan_agent import PlanAgent
from agents.execute_agent import ExecuteAgent
from agents.review_agent import ReviewAgent
from tools.tools_manager import ToolsManager
from orchestrator.console_logger import ConsoleLogger

class TPEROrchestrator:
    """Main orchestrator for the Think → Plan → Execute → Review workflow."""
    
    def __init__(self, config_path: str = "config.yaml"):
        self.config = self._load_config(config_path)
        self.logger = ConsoleLogger()
        self.tools_manager = ToolsManager()
        
        # Initialize agents
        self.think_agent = ThinkAgent(
            model_id=self.config["agents"]["think"]["model"],
            temperature=self.config["agents"]["think"]["temperature"]
        )
        
        self.plan_agent = PlanAgent(
            model_id=self.config["agents"]["plan"]["model"],
            temperature=self.config["agents"]["plan"]["temperature"]
        )
        
        self.execute_agent = ExecuteAgent(
            tools_manager=self.tools_manager,
            model_id=self.config["agents"]["execute"]["model"],
            temperature=self.config["agents"]["execute"]["temperature"]
        )
        
        self.review_agent = ReviewAgent(
            model_id=self.config["agents"]["review"]["model"],
            temperature=self.config["agents"]["review"]["temperature"]
        )
        
        # Orchestrator settings
        self.max_iterations = self.config["orchestrator"]["max_iterations"]
        self.timeout_seconds = self.config["orchestrator"]["timeout_seconds"]
        
        # Initialize tools
        self.tools_manager.discover_tools()
    
    def _load_config(self, config_path: str) -> Dict[str, Any]:
        """Load configuration from YAML file."""
        try:
            with open(config_path, 'r') as f:
                return yaml.safe_load(f)
        except FileNotFoundError:
            # Return default configuration
            return {
                "orchestrator": {"max_iterations": 5, "timeout_seconds": 300},
                "agents": {
                    "think": {"model": "gpt-4o", "temperature": 0.7},
                    "plan": {"model": "gpt-4o", "temperature": 0.5},
                    "execute": {"model": "gpt-4o", "temperature": 0.3},
                    "review": {"model": "gpt-4o", "temperature": 0.6}
                },
                "tools": {"cache_enabled": True, "cache_ttl": 3600}
            }
    
    async def orchestrate(self, query: str, context: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """Main orchestration method implementing the TPER workflow."""
        
        self.logger.log_orchestrator_start(query)
        
        # Initialize context
        if context is None:
            context = {}
        
        iteration = 0
        final_result = None
        
        try:
            while iteration < self.max_iterations:
                iteration += 1
                self.logger.log_iteration_start(iteration)
                
                # THINK Phase
                task_analysis = await self._think_phase(query, context)
                
                # PLAN Phase
                execution_plan = await self._plan_phase(task_analysis)
                
                # EXECUTE Phase
                execution_results = await self._execute_phase(execution_plan)
                
                # REVIEW Phase
                review_results = await self._review_phase(query, task_analysis, execution_results)
                
                # Decision making
                decision = review_results.get("decision", "complete")
                
                if decision == "complete":
                    final_result = {
                        "status": "completed",
                        "iteration": iteration,
                        "task_analysis": task_analysis,
                        "execution_plan": execution_plan,
                        "execution_results": execution_results,
                        "review_results": review_results
                    }
                    break
                elif decision == "retry":
                    self.logger.log_decision("retry", "Retrying with same plan")
                    context["retry_feedback"] = review_results.get("feedback_for_next_iteration", "")
                    continue
                elif decision == "replan":
                    self.logger.log_decision("replan", "Creating new plan based on feedback")
                    context["replan_feedback"] = review_results.get("feedback_for_next_iteration", "")
                    context["previous_results"] = execution_results
                    continue
                elif decision == "iterate":
                    self.logger.log_decision("iterate", "Continuing with new iteration")
                    context["iteration_feedback"] = review_results.get("feedback_for_next_iteration", "")
                    context["previous_results"] = execution_results
                    continue
                else:
                    # Unknown decision, default to complete
                    final_result = {
                        "status": "completed_with_unknown_decision",
                        "iteration": iteration,
                        "task_analysis": task_analysis,
                        "execution_plan": execution_plan,
                        "execution_results": execution_results,
                        "review_results": review_results
                    }
                    break
            
            if final_result is None:
                final_result = {
                    "status": "max_iterations_reached",
                    "iteration": iteration,
                    "message": f"Reached maximum iterations ({self.max_iterations})"
                }
        
        except Exception as e:
            self.logger.log_error(str(e))
            final_result = {
                "status": "error",
                "iteration": iteration,
                "error": str(e)
            }
        
        self.logger.log_orchestrator_complete(final_result)
        return final_result
    
    async def _think_phase(self, query: str, context: Dict[str, Any]) -> Dict[str, Any]:
        """Execute the Think phase."""
        self.logger.log_phase_start("Think", "Analyzing query and breaking down into tasks")
        
        try:
            task_analysis = await self.think_agent.analyze(query, context)
            self.logger.log_phase_result("Think", task_analysis)
            return task_analysis
        except Exception as e:
            self.logger.log_error(str(e), "Think")
            raise
    
    async def _plan_phase(self, task_analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Execute the Plan phase."""
        self.logger.log_phase_start("Plan", "Creating detailed execution plan")
        
        try:
            available_tools = [tool.name for tool in self.tools_manager.get_all_tools()]
            available_tools.extend(self.tools_manager.get_agno_builtin_tools())
            
            execution_plan = await self.plan_agent.create_plan(task_analysis, available_tools)
            self.logger.log_phase_result("Plan", execution_plan)
            return execution_plan
        except Exception as e:
            self.logger.log_error(str(e), "Plan")
            raise
    
    async def _execute_phase(self, execution_plan: Dict[str, Any]) -> Dict[str, Any]:
        """Execute the Execute phase."""
        self.logger.log_phase_start("Execute", "Executing plan using available tools")
        
        try:
            execution_results = await self.execute_agent.execute_plan(execution_plan)
            
            # Log individual tool executions
            for result in execution_results.get("execution_results", []):
                if result.get("success"):
                    self.logger.log_tool_execution(
                        result.get("tool_used", "unknown"),
                        {"step_id": result.get("step_id")},
                        result.get("result", "")
                    )
            
            self.logger.log_phase_result("Execute", execution_results)
            return execution_results
        except Exception as e:
            self.logger.log_error(str(e), "Execute")
            raise
    
    async def _review_phase(self, query: str, task_analysis: Dict[str, Any], execution_results: Dict[str, Any]) -> Dict[str, Any]:
        """Execute the Review phase."""
        self.logger.log_phase_start("Review", "Evaluating results and deciding next actions")
        
        try:
            review_results = await self.review_agent.review_execution(query, task_analysis, execution_results)
            self.logger.log_phase_result("Review", review_results)
            return review_results
        except Exception as e:
            self.logger.log_error(str(e), "Review")
            raise

# Main execution function
async def main():
    """Main function to run the TPER orchestrator."""
    orchestrator = TPEROrchestrator()
    
    # Example query
    query = "Find information about the latest AI developments and create a summary report"
    
    result = await orchestrator.orchestrate(query)
    
    print("\n" + "="*50)
    print("FINAL ORCHESTRATION RESULT")
    print("="*50)
    print(f"Status: {result.get('status')}")
    print(f"Iterations: {result.get('iteration')}")
    
    if result.get('status') == 'completed':
        print("✅ Task completed successfully!")
    else:
        print(f"⚠️ Task ended with status: {result.get('status')}")

if __name__ == "__main__":
    asyncio.run(main())
