import math
import operator
from typing import Union

class CalculatorTool:
    """Safe calculator tool for mathematical operations."""
    
    name = "calculator_tool"
    description = "Perform mathematical calculations safely"
    
    def __init__(self):
        # Safe operations mapping
        self.operations = {
            '+': operator.add,
            '-': operator.sub,
            '*': operator.mul,
            '/': operator.truediv,
            '**': operator.pow,
            'sqrt': math.sqrt,
            'sin': math.sin,
            'cos': math.cos,
            'tan': math.tan,
            'log': math.log,
            'abs': abs,
            'round': round
        }
    
    def run(self, expression: str) -> str:
        """Execute a mathematical calculation safely."""
        try:
            # Simple expression evaluation for basic math
            # In production, use a proper math expression parser
            if any(op in expression for op in ['import', 'exec', 'eval', '__']):
                return "Error: Unsafe expression detected"
            
            # Replace common math functions
            expression = expression.replace('sqrt', 'math.sqrt')
            expression = expression.replace('sin', 'math.sin')
            expression = expression.replace('cos', 'math.cos')
            expression = expression.replace('tan', 'math.tan')
            expression = expression.replace('log', 'math.log')
            
            # Evaluate safely with limited scope
            allowed_names = {
                "__builtins__": {},
                "math": math,
                "abs": abs,
                "round": round,
                "min": min,
                "max": max,
                "sum": sum
            }
            
            result = eval(expression, allowed_names)
            return f"Result: {result}"
            
        except Exception as e:
            return f"Calculation error: {str(e)}"
