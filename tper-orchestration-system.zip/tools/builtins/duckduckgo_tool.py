import httpx
import json
from typing import Dict, Any

class DuckDuckGoTool:
    """Web search tool using DuckDuckGo API."""
    
    name = "duckduckgo_tool"
    description = "Search the web using DuckDuckGo"
    
    def __init__(self):
        self.base_url = "https://api.duckduckgo.com/"
    
    async def run(self, query: str, max_results: int = 5) -> str:
        """Perform a web search using DuckDuckGo."""
        try:
            async with httpx.AsyncClient() as client:
                params = {
                    'q': query,
                    'format': 'json',
                    'no_html': '1',
                    'skip_disambig': '1'
                }
                
                response = await client.get(self.base_url, params=params)
                data = response.json()
                
                # Extract relevant results
                results = []
                
                # Abstract (direct answer)
                if data.get('Abstract'):
                    results.append(f"Direct Answer: {data['Abstract']}")
                
                # Related topics
                if data.get('RelatedTopics'):
                    for i, topic in enumerate(data['RelatedTopics'][:max_results]):
                        if isinstance(topic, dict) and 'Text' in topic:
                            results.append(f"Result {i+1}: {topic['Text']}")
                
                return "\n\n".join(results) if results else f"No results found for: {query}"
                
        except Exception as e:
            return f"Search error: {str(e)}"
    
    def run(self, query: str, max_results: int = 5) -> str:
        """Synchronous wrapper for async search."""
        import asyncio
        try:
            loop = asyncio.get_event_loop()
            return loop.run_until_complete(self.run_async(query, max_results))
        except:
            # Fallback for environments without async support
            return f"Search results for '{query}': [Simulated results - integrate with actual DuckDuckGo API]"
    
    async def run_async(self, query: str, max_results: int = 5) -> str:
        """Async version of search."""
        return await self.run(query, max_results)
