import os
from pathlib import Path
from typing import Optional

class FileTool:
    """File operations tool for reading and writing files."""
    
    name = "file_tool"
    description = "Read and write files safely"
    
    def __init__(self):
        self.allowed_extensions = {'.txt', '.md', '.json', '.yaml', '.yml', '.csv', '.log'}
        self.max_file_size = 10 * 1024 * 1024  # 10MB limit
    
    def run(self, operation: str, file_path: str, content: Optional[str] = None) -> str:
        """Perform file operations safely."""
        try:
            path = Path(file_path)
            
            # Security checks
            if not self._is_safe_path(path):
                return "Error: Unsafe file path"
            
            if operation == "read":
                return self._read_file(path)
            elif operation == "write" and content is not None:
                return self._write_file(path, content)
            elif operation == "exists":
                return f"File exists: {path.exists()}"
            elif operation == "list":
                return self._list_directory(path)
            else:
                return f"Error: Unknown operation '{operation}' or missing content"
                
        except Exception as e:
            return f"File operation error: {str(e)}"
    
    def _is_safe_path(self, path: Path) -> bool:
        """Check if the file path is safe to access."""
        try:
            # Resolve path and check if it's within allowed directories
            resolved = path.resolve()
            
            # Don't allow access to system directories
            forbidden_dirs = {'/etc', '/sys', '/proc', '/dev', '/root'}
            for forbidden in forbidden_dirs:
                if str(resolved).startswith(forbidden):
                    return False
            
            # Check file extension
            if path.suffix and path.suffix.lower() not in self.allowed_extensions:
                return False
            
            return True
        except:
            return False
    
    def _read_file(self, path: Path) -> str:
        """Read file content."""
        if not path.exists():
            return f"Error: File '{path}' does not exist"
        
        if path.stat().st_size > self.max_file_size:
            return f"Error: File too large (max {self.max_file_size} bytes)"
        
        try:
            with open(path, 'r', encoding='utf-8') as f:
                content = f.read()
            return f"File content ({len(content)} characters):\n\n{content}"
        except UnicodeDecodeError:
            return "Error: File contains non-text data"
    
    def _write_file(self, path: Path, content: str) -> str:
        """Write content to file."""
        if len(content.encode('utf-8')) > self.max_file_size:
            return f"Error: Content too large (max {self.max_file_size} bytes)"
        
        # Create directory if it doesn't exist
        path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(path, 'w', encoding='utf-8') as f:
            f.write(content)
        
        return f"Successfully wrote {len(content)} characters to '{path}'"
    
    def _list_directory(self, path: Path) -> str:
        """List directory contents."""
        if not path.exists():
            return f"Error: Directory '{path}' does not exist"
        
        if not path.is_dir():
            return f"Error: '{path}' is not a directory"
        
        try:
            items = []
            for item in sorted(path.iterdir()):
                item_type = "DIR" if item.is_dir() else "FILE"
                size = f"({item.stat().st_size} bytes)" if item.is_file() else ""
                items.append(f"{item_type}: {item.name} {size}")
            
            return f"Directory listing for '{path}':\n" + "\n".join(items)
        except PermissionError:
            return f"Error: Permission denied accessing '{path}'"
