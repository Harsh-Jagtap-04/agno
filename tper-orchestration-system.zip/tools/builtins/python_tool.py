import sys
import io
import contextlib
from typing import Dict, Any

class PythonTool:
    """Safe Python code execution tool."""
    
    name = "python_tool"
    description = "Execute Python code safely in a restricted environment"
    
    def __init__(self):
        self.forbidden_imports = {
            'os', 'sys', 'subprocess', 'importlib', 'exec', 'eval',
            'open', 'file', '__import__', 'compile', 'globals', 'locals'
        }
    
    def run(self, code: str) -> str:
        """Execute Python code safely."""
        try:
            # Basic security checks
            if any(forbidden in code for forbidden in self.forbidden_imports):
                return "Error: Code contains forbidden operations"
            
            if any(dangerous in code for dangerous in ['import os', 'import sys', '__']):
                return "Error: Potentially unsafe code detected"
            
            # Capture output
            output_buffer = io.StringIO()
            error_buffer = io.StringIO()
            
            # Create restricted execution environment
            restricted_globals = {
                '__builtins__': {
                    'print': lambda *args, **kwargs: print(*args, file=output_buffer, **kwargs),
                    'len': len,
                    'str': str,
                    'int': int,
                    'float': float,
                    'list': list,
                    'dict': dict,
                    'tuple': tuple,
                    'set': set,
                    'range': range,
                    'enumerate': enumerate,
                    'zip': zip,
                    'sum': sum,
                    'min': min,
                    'max': max,
                    'abs': abs,
                    'round': round,
                    'sorted': sorted,
                    'reversed': reversed,
                }
            }
            
            # Execute code
            with contextlib.redirect_stderr(error_buffer):
                exec(code, restricted_globals)
            
            # Get results
            output = output_buffer.getvalue()
            errors = error_buffer.getvalue()
            
            result = []
            if output:
                result.append(f"Output:\n{output}")
            if errors:
                result.append(f"Errors:\n{errors}")
            
            return "\n\n".join(result) if result else "Code executed successfully (no output)"
            
        except Exception as e:
            return f"Python execution error: {str(e)}"
