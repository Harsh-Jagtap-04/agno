import httpx
import json
from typing import Optional

class WikipediaTool:
    """Wikipedia search and content retrieval tool."""
    
    name = "wikipedia_tool"
    description = "Search Wikipedia for information"
    
    def __init__(self):
        self.base_url = "https://en.wikipedia.org/api/rest_v1"
        self.search_url = "https://en.wikipedia.org/w/api.php"
    
    async def run_async(self, query: str, max_results: int = 3) -> str:
        """Search Wikipedia and return article summaries."""
        try:
            async with httpx.AsyncClient() as client:
                # First, search for articles
                search_params = {
                    'action': 'query',
                    'format': 'json',
                    'list': 'search',
                    'srsearch': query,
                    'srlimit': max_results
                }
                
                search_response = await client.get(self.search_url, params=search_params)
                search_data = search_response.json()
                
                if 'query' not in search_data or 'search' not in search_data['query']:
                    return f"No Wikipedia articles found for: {query}"
                
                results = []
                
                # Get summaries for each article
                for article in search_data['query']['search'][:max_results]:
                    title = article['title']
                    snippet = article.get('snippet', '').replace('<span class="searchmatch">', '').replace('</span>', '')
                    
                    # Get full summary
                    summary_url = f"{self.base_url}/page/summary/{title.replace(' ', '_')}"
                    try:
                        summary_response = await client.get(summary_url)
                        summary_data = summary_response.json()
                        
                        extract = summary_data.get('extract', snippet)
                        page_url = summary_data.get('content_urls', {}).get('desktop', {}).get('page', '')
                        
                        results.append(f"**{title}**\n{extract}\nURL: {page_url}")
                        
                    except:
                        # Fallback to search snippet
                        results.append(f"**{title}**\n{snippet}")
                
                return f"Wikipedia search results for '{query}':\n\n" + "\n\n---\n\n".join(results)
                
        except Exception as e:
            return f"Wikipedia search error: {str(e)}"
    
    def run(self, query: str, max_results: int = 3) -> str:
        """Synchronous wrapper for Wikipedia search."""
        import asyncio
        try:
            loop = asyncio.get_event_loop()
            return loop.run_until_complete(self.run_async(query, max_results))
        except:
            # Fallback for environments without async support
            return f"Wikipedia search for '{query}': [Simulated results - integrate with actual Wikipedia API]"
