import os
import httpx
import json
from typing import Dict, Any, Optional

class GitHubMCPServer:
    """GitHub integration via MCP-like interface."""
    
    name = "github_mcp_server"
    description = "Interact with GitHub repositories"
    
    def __init__(self):
        self.github_token = os.getenv("GITHUB_TOKEN")
        self.base_url = "https://api.github.com"
        self.headers = {
            "Accept": "application/vnd.github.v3+json",
            "User-Agent": "TPER-Orchestrator/1.0"
        }
        
        if self.github_token:
            self.headers["Authorization"] = f"token {self.github_token}"
    
    async def run_async(self, operation: str, **kwargs) -> str:
        """Execute GitHub operations."""
        try:
            if not self.github_token:
                return "Error: GITHUB_TOKEN environment variable not set"
            
            if operation == "get_repo_info":
                return await self._get_repo_info(kwargs.get("repo"))
            elif operation == "list_commits":
                return await self._list_commits(kwargs.get("repo"), kwargs.get("limit", 10))
            elif operation == "get_issues":
                return await self._get_issues(kwargs.get("repo"), kwargs.get("state", "open"))
            elif operation == "search_repos":
                return await self._search_repos(kwargs.get("query"))
            else:
                return f"Error: Unknown operation '{operation}'"
                
        except Exception as e:
            return f"GitHub API error: {str(e)}"
    
    def run(self, operation: str, **kwargs) -> str:
        """Synchronous wrapper for GitHub operations."""
        import asyncio
        try:
            loop = asyncio.get_event_loop()
            return loop.run_until_complete(self.run_async(operation, **kwargs))
        except:
            return f"GitHub operation '{operation}' completed [Simulated - integrate with actual GitHub API]"
    
    async def _get_repo_info(self, repo: str) -> str:
        """Get repository information."""
        if not repo:
            return "Error: Repository name required"
        
        async with httpx.AsyncClient() as client:
            response = await client.get(f"{self.base_url}/repos/{repo}", headers=self.headers)
            
            if response.status_code == 404:
                return f"Repository '{repo}' not found"
            elif response.status_code != 200:
                return f"GitHub API error: {response.status_code}"
            
            data = response.json()
            
            return f"""Repository: {data['full_name']}
Description: {data.get('description', 'No description')}
Language: {data.get('language', 'Unknown')}
Stars: {data['stargazers_count']}
Forks: {data['forks_count']}
Open Issues: {data['open_issues_count']}
Created: {data['created_at']}
Updated: {data['updated_at']}
URL: {data['html_url']}"""
    
    async def _list_commits(self, repo: str, limit: int = 10) -> str:
        """List recent commits."""
        if not repo:
            return "Error: Repository name required"
        
        async with httpx.AsyncClient() as client:
            params = {"per_page": min(limit, 100)}
            response = await client.get(f"{self.base_url}/repos/{repo}/commits", 
                                      headers=self.headers, params=params)
            
            if response.status_code != 200:
                return f"GitHub API error: {response.status_code}"
            
            commits = response.json()
            
            result = [f"Recent commits for {repo}:"]
            for commit in commits[:limit]:
                sha = commit['sha'][:8]
                message = commit['commit']['message'].split('\n')[0]
                author = commit['commit']['author']['name']
                date = commit['commit']['author']['date']
                
                result.append(f"• {sha} - {message} ({author}, {date})")
            
            return "\n".join(result)
    
    async def _get_issues(self, repo: str, state: str = "open") -> str:
        """Get repository issues."""
        if not repo:
            return "Error: Repository name required"
        
        async with httpx.AsyncClient() as client:
            params = {"state": state, "per_page": 10}
            response = await client.get(f"{self.base_url}/repos/{repo}/issues", 
                                      headers=self.headers, params=params)
            
            if response.status_code != 200:
                return f"GitHub API error: {response.status_code}"
            
            issues = response.json()
            
            if not issues:
                return f"No {state} issues found for {repo}"
            
            result = [f"{state.title()} issues for {repo}:"]
            for issue in issues:
                number = issue['number']
                title = issue['title']
                author = issue['user']['login']
                created = issue['created_at']
                
                result.append(f"• #{number}: {title} (by {author}, {created})")
            
            return "\n".join(result)
    
    async def _search_repos(self, query: str) -> str:
        """Search for repositories."""
        if not query:
            return "Error: Search query required"
        
        async with httpx.AsyncClient() as client:
            params = {"q": query, "per_page": 5}
            response = await client.get(f"{self.base_url}/search/repositories", 
                                      headers=self.headers, params=params)
            
            if response.status_code != 200:
                return f"GitHub API error: {response.status_code}"
            
            data = response.json()
            repos = data.get('items', [])
            
            if not repos:
                return f"No repositories found for query: {query}"
            
            result = [f"Repository search results for '{query}':"]
            for repo in repos:
                name = repo['full_name']
                desc = repo.get('description', 'No description')[:100]
                stars = repo['stargazers_count']
                language = repo.get('language', 'Unknown')
                
                result.append(f"• {name} - {desc} ({stars} stars, {language})")
            
            return "\n".join(result)
