import os
import importlib.util
import inspect
from typing import Dict, List, Any, Type
from pathlib import Path
import logging

logger = logging.getLogger(__name__)

class ToolsManager:
    """Centralized manager for dynamic tool discovery and loading."""
    
    def __init__(self, tools_dir: str = "tools"):
        self.tools_dir = Path(tools_dir)
        self.loaded_tools: Dict[str, Any] = {}
        self.tool_categories = {
            "builtins": [],
            "agents": [],
            "mcp_servers": []
        }
    
    def discover_tools(self) -> Dict[str, List[Any]]:
        """Dynamically discover and load all tools from subdirectories."""
        logger.info("Starting tool discovery...")
        
        for category in self.tool_categories.keys():
            category_path = self.tools_dir / category
            if category_path.exists():
                self._load_tools_from_directory(category_path, category)
        
        logger.info(f"Tool discovery complete. Loaded {len(self.loaded_tools)} tools.")
        return self.tool_categories
    
    def _load_tools_from_directory(self, directory: Path, category: str):
        """Load tools from a specific directory."""
        for file_path in directory.glob("*.py"):
            if file_path.name.startswith("__"):
                continue
            
            try:
                module_name = f"tools.{category}.{file_path.stem}"
                spec = importlib.util.spec_from_file_location(module_name, file_path)
                module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(module)
                
                # Look for tool classes in the module
                for name, obj in inspect.getmembers(module, inspect.isclass):
                    if hasattr(obj, 'name') and hasattr(obj, 'run'):
                        tool_instance = obj()
                        self.loaded_tools[tool_instance.name] = tool_instance
                        self.tool_categories[category].append(tool_instance)
                        logger.info(f"Loaded tool: {tool_instance.name} from {category}")
            
            except Exception as e:
                logger.error(f"Failed to load tool from {file_path}: {e}")
    
    def get_tool(self, tool_name: str) -> Any:
        """Get a specific tool by name."""
        return self.loaded_tools.get(tool_name)
    
    def get_tools_by_category(self, category: str) -> List[Any]:
        """Get all tools from a specific category."""
        return self.tool_categories.get(category, [])
    
    def get_all_tools(self) -> List[Any]:
        """Get all loaded tools."""
        return list(self.loaded_tools.values())
    
    def get_agno_builtin_tools(self) -> List[str]:
        """Get list of Agno's built-in tool names."""
        return [
            "duckduckgo_search",
            "calculator",
            "file_operations",
            "python_executor",
            "wikipedia_search"
        ]
