# 🔄 TPER Workflow 2.0 System

A **Think → Plan → Execute → Review** AI agent orchestration platform built with the Agno framework. This modular, extensible system demonstrates sophisticated multi-agent workflows through a structured four-phase process.

## 🎯 Overview

The TPER Workflow System is a comprehensive AI agent orchestration platform that breaks down complex user tasks into manageable phases:

- **🧠 ThinkAgent**: Analyzes user input and asks clarifying questions
- **🧩 PlanAgent**: Creates detailed execution plans with tool mapping  
- **⚙️ ExecuteAgent**: Executes plans using real Agno tools
- **🧪 ReviewAgent**: Evaluates results and determines next steps

## 🏗️ Architecture

```
modular-tools-manager/
├── agents/                     # TPER Agent implementations
│   ├── think_agent.py         # Problem analysis & clarification
│   ├── plan_agent.py          # Strategic task planning
│   ├── execute_agent.py       # Tool orchestration
│   └── review_agent.py        # Intelligent decision making
├── orchestrator/              # Workflow coordination
│   ├── tper_orchestrator.py   # Main workflow manager
│   └── console_logger.py      # Visual console output
├── tools/                     # Tool management system
│   ├── tools_manager.py       # Central tool registry
│   ├── builtins/              # Built-in Agno tools
│   │   ├── calculator_tool.py
│   │   ├── duckduckgo_tool.py
│   │   ├── wikipedia_tool.py
│   │   ├── python_tool.py
│   │   └── file_tool.py
│   ├── agents/                # Agent-based tools
│   │   └── formatting_agent.py
│   └── mcp_servers/           # MCP server integrations
│       └── github_mcp_server.py
├── config.yaml                # System configuration
├── main.py                    # CLI entry point
├── gradio_ui.py              # Modern web interface
└── requirements.txt          # Dependencies
```

## 🚀 Quick Start

### 1. Installation

```bash
# Clone or download the system
cd modular-tools-manager

# Install dependencies
pip install -r requirements.txt

# Set up environment variables
export OPENAI_API_KEY="your_openai_api_key_here"
```

### 2. Basic Usage

```bash
# Execute a specific task
python main.py --task "Calculate 15 + 25 and save the result to a file"

# Launch interactive console
python main.py --console

# Start web interface
python main.py --ui
```

### 3. Configuration

Edit `config.yaml` to customize:
- Tool enablement/disablement
- Agent behavior parameters
- System limits and thresholds
- Security settings

## 💻 Usage Examples

### Command Line Interface

```bash
# Simple calculation
python main.py -t "Calculate 15 + 25"

# Web search
python main.py -t "Search for information about machine learning"

# File operations
python main.py -t "Create a file with today's date and time"

# Complex multi-step task
python main.py -t "Search for Python tutorials, summarize the findings, and save to a file"
```

### Interactive Console Mode

```bash
python main.py --console
```

```
🎯 Enter your request: Calculate the square root of 144 and tell me about the result
```

### Web Interface

```bash
python main.py --ui
```

Opens a modern Gradio interface at `http://localhost:7860` with:
- Real-time TPER workflow visualization
- Interactive chat interface
- System status monitoring
- Example prompts

## 🔧 Available Tools

### Built-in Tools (Always Available)

- **🧮 Calculator**: Mathematical computations and calculations
- **🔍 DuckDuckGo**: Web search for current information
- **📚 Wikipedia**: Encyclopedia search and knowledge retrieval
- **🐍 Python**: Code execution environment
- **📁 File Operations**: File system access and management

### Agent Tools (Configurable)

- **✨ Formatting Agent**: Text and data formatting capabilities

### MCP Servers (Configurable)

- **🔗 GitHub MCP**: Repository management and code access

## 🎮 User Interfaces

### 1. Command Line Interface

Execute single tasks or get help:

```bash
python main.py --task "your request here"
python main.py --help
```

### 2. Interactive Console

Full-featured console with TPER visualization:

```bash
python main.py --console

🔄 TPER WORKFLOW 2.0 - STARTED
🎯 User Request: Calculate 15 + 25 and save result

[Iteration 1]
Phase: Think 🧠
-> User Input: 'Calculate 15 + 25 and save result'
-> Analysis complete with 95% confidence

Phase: Plan 🧩  
-> Available Tools: ['calculator', 'file_operations']
-> Created 2 execution steps

Phase: Execute ⚙️
-> Calling: calculator (Step 1)
   Output: 40
   ✅ Step 1 completed in 0.12s

-> Calling: file_operations (Step 2)  
   Output: Successfully saved result
   ✅ Step 2 completed in 0.08s

Phase: Review 🧪
-> Success Rate: 100%
-> Decision: COMPLETE
-> Task Completed: ✅

═══════════════════════════════════════════
            COMPLETED ✅
═══════════════════════════════════════════
```

### 3. Gradio Web Interface

Modern web-based interface with:

- **Horizontal 30-70 split layout**
- **Real-time TPER phase visualization** 
- **Interactive chat interface**
- **System status monitoring**
- **6 example prompts** (click to populate):
  1. "Calculate 15 + 25 and save the result to a file"
  2. "Search for current information about artificial intelligence"  
  3. "Get weather information for Tokyo, Japan"
  4. "Find Wikipedia article about machine learning"
  5. "Execute Python code to sum numbers 1 through 10"
  6. "Create a simple text file with today's date"

## 🔍 TPER Workflow Details

### 🧠 Think Phase

- **Input Analysis**: Parses and understands user requests
- **Interactive Clarification**: Asks up to 3 follow-up questions for ambiguous requests
- **Problem Breakdown**: Structures tasks into actionable components
- **Complexity Assessment**: Categorizes tasks as simple, moderate, or complex

### 🧩 Plan Phase  

- **Tool Mapping**: Matches sub-tasks to appropriate Agno tools
- **Dependency Management**: Identifies execution order and dependencies
- **Plan Validation**: Ensures all required tools are available
- **Fallback Planning**: Creates alternative approaches for robustness

### ⚙️ Execute Phase

- **Direct Tool Calling**: Interfaces with actual Agno built-in tools
- **Progress Tracking**: Monitors execution with detailed logging
- **Error Handling**: Graceful failure management with recovery options
- **Result Aggregation**: Combines outputs into coherent final results

### 🧪 Review Phase

- **Success Analysis**: Evaluates whether original goals were achieved
- **Quality Assessment**: Calculates quality scores based on multiple factors
- **Decision Making**: Determines whether to complete, retry, or revise
- **Iteration Control**: Manages workflow continuation intelligently

## 🛠️ Configuration

### System Settings (`config.yaml`)

```yaml
system:
  max_iterations: 5          # Maximum TPER cycles
  enable_console_logs: true  # Colored console output

agents:
  think_agent:
    max_clarifications: 3    # Maximum clarifying questions
  review_agent:
    success_rate_threshold: 0.8  # Minimum success rate for completion
```

### Tool Configuration

```yaml
builtin_tools:
  calculator:
    enabled: true
  duckduckgo:
    enabled: true
  # ... other tools

agent_tools:
  formatting_agent:
    enabled: false          # Optional tools

mcp_servers:
  github_mcp:
    enabled: false         # External integrations
```

### Environment Variables

```bash
# Required
export OPENAI_API_KEY="your_openai_api_key_here"

# Optional
export TPER_CONFIG_PATH="custom_config.yaml"
export TPER_LOG_LEVEL="INFO"
```

## 🧪 Example Workflows

### Simple Calculation

**Input**: "Calculate 15 + 25"

```
🧠 Think: Mathematical calculation identified
🧩 Plan: Use calculator tool  
⚙️ Execute: calculator(15 + 25) → 40
🧪 Review: Success (100%) → Complete
```

### Multi-step Research Task

**Input**: "Find information about Python and save it to a file"

```
🧠 Think: Research + file operation task
🧩 Plan: 1) Wikipedia search 2) File save
⚙️ Execute: 
   Step 1: wikipedia("Python programming") → Article content
   Step 2: file_operations("save to python_info.txt") → File created
🧪 Review: Success (100%) → Complete
```

### Complex Task with Iterations

**Input**: "Get current weather and explain what affects it"

```
Iteration 1:
🧠 Think: Weather lookup + explanation needed
🧩 Plan: 1) DuckDuckGo weather search 2) Wikipedia weather factors
⚙️ Execute: Both steps successful
🧪 Review: Partial success (80%) → Continue for better explanation

Iteration 2:  
🧠 Think: Use previous results
🧩 Plan: Combine results with Python formatting
⚙️ Execute: Format comprehensive response
🧪 Review: Success (95%) → Complete
```

## 🔒 Security Features

- **Sandboxed Execution**: All code execution is restricted and sandboxed
- **File System Isolation**: File operations limited to designated workspace
- **Input Validation**: All inputs validated before processing
- **No Network Access**: Tools cannot make unrestricted network calls
- **Safe Tool Registry**: Only approved tools can be loaded

## 🚀 Extending the System

### Adding Custom Tools

1. Create tool class in appropriate directory:

```python
class CustomTool:
    def __init__(self):
        self.name = "custom_tool"
        self.description = "Custom tool functionality"

    def execute(self, input_data):
        return f"Processed: {input_data}"
```

2. Register in `config.yaml`:

```yaml
custom_tools:
  custom_tool:
    enabled: true
```

### Creating New Agents

1. Implement agent following the pattern:

```python
class CustomAgent:
    def __init__(self):
        self.name = "custom_agent"

    def process(self, data):
        # Agent logic here
        return result
```

2. Integrate into orchestrator workflow

### Adding MCP Servers

1. Implement MCP server interface:

```python
class CustomMcpServer:
    def __init__(self):
        self.name = "custom_mcp"

    def execute(self, command):
        # MCP server logic
        return response
```

## 📊 System Monitoring

### Console Logging

Detailed phase-by-phase execution logs with:
- Color-coded output for different phases
- Execution timing and performance metrics  
- Tool call details and results
- Error handling and recovery information

### Web Interface Monitoring

- Real-time workflow visualization
- System status and tool availability
- Execution history and statistics
- Performance metrics and insights

## 🐛 Troubleshooting

### Common Issues

**OpenAI API Key Not Set**
```bash
export OPENAI_API_KEY="your_key_here"
```

**Tools Not Loading**
- Check `config.yaml` tool enablement
- Verify tool dependencies are installed
- Review console error messages

**Web Interface Not Starting**
```bash
pip install gradio>=4.0.0
```

**File Operations Failing**
- Check file workspace directory permissions
- Verify allowed file extensions in config

### Debug Mode

```bash
python main.py --task "test request" --no-colors > debug.log 2>&1
```

## 📚 API Reference

### TPEROrchestrator

Main orchestration class:

```python
orchestrator = TPEROrchestrator(
    openai_api_key="key",
    enable_console_logs=True,
    max_iterations=5
)

result = orchestrator.execute_workflow(
    user_input="Calculate 15 + 25",
    interactive=False
)
```

### Individual Agents

```python
from agents.think_agent import ThinkAgent

think_agent = ThinkAgent(api_key="key")
analysis = think_agent.get_task_breakdown("user request")
```

## 🤝 Contributing

This system is designed for educational and demonstration purposes. To extend:

1. Follow the modular architecture patterns
2. Add comprehensive error handling
3. Include unit tests for new components  
4. Update configuration files appropriately
5. Maintain the TPER workflow paradigm

## 📝 License

This TPER Workflow 2.0 System is provided as-is for educational and demonstration purposes. Modify and extend according to your needs.

## 🙏 Acknowledgments

- Built using the Agno framework architecture
- Inspired by multi-agent AI orchestration patterns
- Implements the TPER (Think-Plan-Execute-Review) workflow methodology

---

**Ready to orchestrate AI agents?** 🚀

```bash
python main.py --console
```

Welcome to the future of structured AI agent workflows!
