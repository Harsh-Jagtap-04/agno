"""
TPER ExecuteAgent - Tool Orchestration and Execution
Executes planned tasks using available tools with comprehensive error handling.
"""

import json
import time
from typing import Dict, List, Any, Optional
from datetime import datetime

class ExecuteAgent:
    def __init__(self, tools_manager):
        """Initialize ExecuteAgent with tools manager reference."""
        self.tools_manager = tools_manager
        self.execution_history = []

    def execute_plan(self, plan: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute the complete plan step by step.

        Args:
            plan: Plan dictionary from PlanAgent

        Returns:
            Dict containing execution results and status
        """
        print(f"\n⚙️ ExecuteAgent: Starting plan execution...")
        print(f"-> Plan ID: {plan.get('plan_id', 'unknown')}")
        print(f"-> Total Steps: {plan.get('total_steps', 0)}")

        execution_start = time.time()
        results = []
        failed_steps = []

        # Execute each step
        for step in plan.get('steps', []):
            step_result = self._execute_step(step)
            results.append(step_result)

            if not step_result['success']:
                failed_steps.append(step['step_id'])

        execution_time = time.time() - execution_start

        # Calculate success metrics
        total_steps = len(results)
        successful_steps = len([r for r in results if r['success']])
        success_rate = successful_steps / total_steps if total_steps > 0 else 0

        # Compile execution results
        execution_result = {
            "plan_id": plan.get('plan_id'),
            "execution_id": f"exec_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            "status": "completed" if not failed_steps else "partial_failure",
            "total_steps": total_steps,
            "successful_steps": successful_steps,
            "failed_steps": len(failed_steps),
            "success_rate": success_rate,
            "execution_time": execution_time,
            "step_results": results,
            "failed_step_ids": failed_steps,
            "final_output": self._compile_final_output(results),
            "executed_at": datetime.now().isoformat()
        }

        print(f"-> Execution completed: {successful_steps}/{total_steps} steps successful ({success_rate:.1%})")
        print(f"-> Total execution time: {execution_time:.2f}s")

        self.execution_history.append(execution_result)
        return execution_result

    def _execute_step(self, step: Dict[str, Any]) -> Dict[str, Any]:
        """
        Execute a single plan step.

        Args:
            step: Step dictionary from plan

        Returns:
            Dict containing step execution result
        """
        step_id = step.get('step_id', 0)
        tool_name = step.get('tool', 'unknown')
        task = step.get('task', '')

        print(f"\n-> Executing Step {step_id}: {task}")
        print(f"   Tool: {tool_name}")

        step_start = time.time()

        try:
            # Get the tool
            tool = self.tools_manager.get_tool(tool_name)
            if not tool:
                return self._create_error_result(step, f"Tool '{tool_name}' not found")

            # Prepare tool input
            tool_input = self._prepare_tool_input(task, tool_name)
            print(f"   Input: {tool_input}")

            # Execute tool
            tool_output = tool.execute(tool_input)
            execution_time = time.time() - step_start

            print(f"   Output: {str(tool_output)[:100]}...")
            print(f"   ✅ Step {step_id} completed in {execution_time:.2f}s")

            return {
                "step_id": step_id,
                "task": task,
                "tool": tool_name,
                "input": tool_input,
                "output": tool_output,
                "success": True,
                "execution_time": execution_time,
                "timestamp": datetime.now().isoformat(),
                "error": None
            }

        except Exception as e:
            execution_time = time.time() - step_start
            error_msg = str(e)
            print(f"   ❌ Step {step_id} failed: {error_msg}")

            return self._create_error_result(step, error_msg, execution_time)

    def _create_error_result(self, step: Dict[str, Any], error_msg: str, execution_time: float = 0) -> Dict[str, Any]:
        """Create error result for failed step."""
        return {
            "step_id": step.get('step_id', 0),
            "task": step.get('task', ''),
            "tool": step.get('tool', 'unknown'),
            "input": None,
            "output": None,
            "success": False,
            "execution_time": execution_time,
            "timestamp": datetime.now().isoformat(),
            "error": error_msg
        }

    def _prepare_tool_input(self, task: str, tool_name: str) -> str:
        """
        Prepare appropriate input for different tools.

        Args:
            task: Task description
            tool_name: Name of the tool to be used

        Returns:
            Formatted input string for the tool
        """
        # Extract relevant parts of task for each tool type
        if tool_name == 'calculator':
            # Try to extract mathematical expression
            import re
            math_pattern = r'[0-9+\-*/().\s]+'
            matches = re.findall(math_pattern, task)
            if matches:
                return max(matches, key=len).strip()
            return task

        elif tool_name in ['duckduckgo', 'wikipedia']:
            # Extract search terms
            search_words = []
            skip_words = {'get', 'find', 'search', 'for', 'about', 'information', 'current', 'latest'}

            words = task.lower().split()
            for word in words:
                if word not in skip_words and len(word) > 2:
                    search_words.append(word)

            return ' '.join(search_words) if search_words else task

        elif tool_name == 'python':
            # For Python tool, pass the task as code or instruction
            if 'calculate' in task.lower() or 'compute' in task.lower():
                return f"# {task}\nprint('{task}')"
            return task

        elif tool_name == 'file_operations':
            # For file operations, extract filename and content if mentioned
            return task

        else:
            # Default: return task as is
            return task

    def _compile_final_output(self, results: List[Dict[str, Any]]) -> str:
        """
        Compile final output from all step results.

        Args:
            results: List of step execution results

        Returns:
            Combined final output string
        """
        output_parts = []

        for result in results:
            if result['success'] and result['output']:
                step_output = str(result['output']).strip()
                if step_output:
                    output_parts.append(f"Step {result['step_id']}: {step_output}")

        if not output_parts:
            return "No successful outputs generated"

        return "\n".join(output_parts)

    def retry_failed_steps(self, execution_result: Dict[str, Any], plan: Dict[str, Any]) -> Dict[str, Any]:
        """
        Retry only the failed steps from previous execution.

        Args:
            execution_result: Previous execution result
            plan: Original plan

        Returns:
            Dict containing retry execution results
        """
        failed_step_ids = execution_result.get('failed_step_ids', [])

        if not failed_step_ids:
            print("\n⚙️ ExecuteAgent: No failed steps to retry")
            return execution_result

        print(f"\n⚙️ ExecuteAgent: Retrying {len(failed_step_ids)} failed steps...")

        retry_results = []
        for step in plan.get('steps', []):
            if step['step_id'] in failed_step_ids:
                retry_result = self._execute_step(step)
                retry_results.append(retry_result)

        # Update original results with retry results
        updated_results = execution_result['step_results'].copy()
        for retry_result in retry_results:
            step_id = retry_result['step_id']
            # Replace the original failed result
            for i, original_result in enumerate(updated_results):
                if original_result['step_id'] == step_id:
                    updated_results[i] = retry_result
                    break

        # Recalculate metrics
        total_steps = len(updated_results)
        successful_steps = len([r for r in updated_results if r['success']])
        success_rate = successful_steps / total_steps if total_steps > 0 else 0

        # Create updated execution result
        updated_execution = execution_result.copy()
        updated_execution['status'] = "completed" if success_rate == 1.0 else "partial_failure"
        updated_execution['successful_steps'] = successful_steps
        updated_execution['failed_steps'] = total_steps - successful_steps
        updated_execution['success_rate'] = success_rate
        updated_execution['step_results'] = updated_results
        updated_execution['failed_step_ids'] = [r['step_id'] for r in updated_results if not r['success']]
        updated_execution['retry_count'] = execution_result.get('retry_count', 0) + 1
        updated_execution['retried_at'] = datetime.now().isoformat()

        print(f"-> Retry completed: {successful_steps}/{total_steps} steps successful ({success_rate:.1%})")

        return updated_execution

    def get_execution_summary(self, execution_result: Dict[str, Any]) -> str:
        """
        Generate human-readable summary of execution results.

        Args:
            execution_result: Execution result dictionary

        Returns:
            Formatted summary string
        """
        status = execution_result.get('status', 'unknown')
        success_rate = execution_result.get('success_rate', 0)
        total_steps = execution_result.get('total_steps', 0)
        successful_steps = execution_result.get('successful_steps', 0)

        summary = f"Execution Summary:\n"
        summary += f"Status: {status.title()}\n"
        summary += f"Success Rate: {success_rate:.1%} ({successful_steps}/{total_steps} steps)\n"

        if execution_result.get('final_output'):
            summary += f"\nFinal Output:\n{execution_result['final_output']}"

        return summary

if __name__ == "__main__":
    # Test the ExecuteAgent (requires tools_manager)
    print("ExecuteAgent module loaded successfully")
