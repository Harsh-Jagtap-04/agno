"""
TPER PlanAgent - Strategic Task Planning
Creates detailed execution plans by mapping tasks to appropriate tools.
"""

import json
from typing import Dict, List, Any, Optional
from datetime import datetime

class PlanAgent:
    def __init__(self, tools_manager):
        """Initialize PlanAgent with tools manager reference."""
        self.tools_manager = tools_manager
        self.plan_history = []

    def create_plan(self, analysis: Dict[str, Any]) -> Dict[str, Any]:
        """
        Create execution plan based on task analysis.

        Args:
            analysis: Task analysis from ThinkAgent

        Returns:
            Dict containing execution plan with tool mappings
        """
        print(f"\n🧩 PlanAgent: Creating execution plan...")
        print(f"-> Main Goal: {analysis.get('main_goal', 'Unknown')}")

        # Get available tools
        available_tools = self.tools_manager.get_available_tools()
        print(f"-> Available Tools: {list(available_tools.keys())}")

        # Extract sub-tasks
        sub_tasks = analysis.get('sub_tasks', [analysis.get('main_goal', '')])

        # Create plan steps
        plan_steps = []
        for i, task in enumerate(sub_tasks):
            tool_name = self._match_task_to_tool(task, available_tools)

            step = {
                "step_id": i + 1,
                "task": task,
                "tool": tool_name,
                "priority": "high" if i == 0 else "medium",
                "dependencies": list(range(1, i + 1)) if i > 0 else [],
                "expected_output": self._predict_output(task, tool_name)
            }
            plan_steps.append(step)

        # Create complete plan
        plan = {
            "plan_id": f"plan_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            "original_goal": analysis.get('main_goal', ''),
            "complexity": analysis.get('complexity', 'moderate'),
            "steps": plan_steps,
            "total_steps": len(plan_steps),
            "estimated_duration": len(plan_steps) * 2,  # 2 seconds per step estimate
            "fallback_tools": self._get_fallback_tools(plan_steps),
            "created_at": datetime.now().isoformat()
        }

        # Log plan details
        print(f"-> Created {len(plan_steps)} execution steps:")
        for step in plan_steps:
            print(f"   Step {step['step_id']}: {step['task'][:50]}... -> {step['tool']}")

        self.plan_history.append(plan)
        return plan

    def _match_task_to_tool(self, task: str, available_tools: Dict) -> str:
        """
        Match a task to the most appropriate tool.

        Args:
            task: Task description
            available_tools: Dictionary of available tools

        Returns:
            Tool name that best matches the task
        """
        task_lower = task.lower()

        # Define task-to-tool mappings
        tool_mappings = {
            'calculator': ['calculate', 'math', 'compute', 'add', 'subtract', 'multiply', 'divide', 'number'],
            'duckduckgo': ['search', 'find', 'look up', 'web', 'internet', 'current', 'news', 'weather'],
            'wikipedia': ['information', 'knowledge', 'history', 'facts', 'encyclopedia', 'learn'],
            'python': ['code', 'script', 'program', 'execute', 'run', 'process', 'data'],
            'file_operations': ['file', 'save', 'read', 'write', 'create', 'document', 'text']
        }

        # Score each available tool
        tool_scores = {}
        for tool_name in available_tools:
            score = 0
            keywords = tool_mappings.get(tool_name, [])
            for keyword in keywords:
                if keyword in task_lower:
                    score += 1
            tool_scores[tool_name] = score

        # Return the highest scoring tool, or first available if no matches
        if tool_scores and max(tool_scores.values()) > 0:
            best_tool = max(tool_scores, key=tool_scores.get)
        else:
            # Default fallback
            if 'duckduckgo' in available_tools:
                best_tool = 'duckduckgo'
            elif available_tools:
                best_tool = list(available_tools.keys())[0]
            else:
                best_tool = 'unknown'

        return best_tool

    def _predict_output(self, task: str, tool_name: str) -> str:
        """Predict expected output based on task and tool."""
        predictions = {
            'calculator': 'Numerical result or calculation',
            'duckduckgo': 'Search results or information',
            'wikipedia': 'Encyclopedia information',
            'python': 'Code execution result',
            'file_operations': 'File operation status'
        }
        return predictions.get(tool_name, 'Tool execution result')

    def _get_fallback_tools(self, plan_steps: List[Dict]) -> List[str]:
        """Get list of fallback tools for each step."""
        fallbacks = []
        for step in plan_steps:
            if step['tool'] == 'duckduckgo':
                fallbacks.append('wikipedia')
            elif step['tool'] == 'wikipedia':
                fallbacks.append('duckduckgo')
            elif step['tool'] == 'calculator':
                fallbacks.append('python')
            else:
                fallbacks.append('duckduckgo')  # General fallback
        return list(set(fallbacks))

    def revise_plan(self, plan: Dict[str, Any], failed_steps: List[int], execution_results: Dict) -> Dict[str, Any]:
        """
        Revise plan based on execution results and failures.

        Args:
            plan: Original plan
            failed_steps: List of step IDs that failed
            execution_results: Results from previous execution attempt

        Returns:
            Revised plan
        """
        print(f"\n🔄 PlanAgent: Revising plan due to {len(failed_steps)} failed steps...")

        # Create revised steps
        revised_steps = []
        step_counter = 1

        for step in plan['steps']:
            if step['step_id'] in failed_steps:
                # Try to find alternative tool
                fallback_tool = self._get_alternative_tool(step['tool'], step['task'])

                revised_step = step.copy()
                revised_step['step_id'] = step_counter
                revised_step['tool'] = fallback_tool
                revised_step['attempt'] = step.get('attempt', 1) + 1
                revised_step['original_tool'] = step['tool']

                revised_steps.append(revised_step)
                print(f"   Revised Step {step_counter}: {step['task'][:50]}... -> {fallback_tool} (was {step['tool']})")
            else:
                # Keep successful steps
                revised_step = step.copy()
                revised_step['step_id'] = step_counter
                revised_steps.append(revised_step)
                print(f"   Kept Step {step_counter}: {step['task'][:50]}... -> {step['tool']}")

            step_counter += 1

        # Create revised plan
        revised_plan = plan.copy()
        revised_plan['plan_id'] = f"revised_{plan['plan_id']}"
        revised_plan['steps'] = revised_steps
        revised_plan['revision_count'] = plan.get('revision_count', 0) + 1
        revised_plan['revised_at'] = datetime.now().isoformat()

        return revised_plan

    def _get_alternative_tool(self, failed_tool: str, task: str) -> str:
        """Get alternative tool for a failed tool."""
        alternatives = {
            'calculator': 'python',
            'duckduckgo': 'wikipedia',
            'wikipedia': 'duckduckgo',
            'python': 'calculator',
            'file_operations': 'python'
        }

        available_tools = self.tools_manager.get_available_tools()
        alternative = alternatives.get(failed_tool, 'duckduckgo')

        if alternative in available_tools:
            return alternative
        else:
            # Return first available tool as last resort
            return list(available_tools.keys())[0] if available_tools else 'unknown'

    def validate_plan(self, plan: Dict[str, Any]) -> Dict[str, Any]:
        """
        Validate plan against available tools and constraints.

        Args:
            plan: Plan to validate

        Returns:
            Validation result with any issues found
        """
        available_tools = self.tools_manager.get_available_tools()
        issues = []

        for step in plan['steps']:
            if step['tool'] not in available_tools:
                issues.append(f"Step {step['step_id']}: Tool '{step['tool']}' not available")

        return {
            "valid": len(issues) == 0,
            "issues": issues,
            "available_tools": list(available_tools.keys())
        }

if __name__ == "__main__":
    # Test the PlanAgent (requires tools_manager)
    print("PlanAgent module loaded successfully")
