"""
TPER ReviewAgent - Intelligent Decision Making
Reviews execution results and determines next steps in the TPER workflow.
"""

import json
from typing import Dict, List, Any, Optional
from datetime import datetime

class ReviewAgent:
    def __init__(self):
        """Initialize ReviewAgent."""
        self.review_history = []
        self.decision_thresholds = {
            'success_rate_completion': 0.8,  # 80% success rate to consider complete
            'success_rate_retry': 0.5,       # 50% success rate to attempt retry
            'max_iterations': 5,              # Maximum TPER iterations
            'max_retries': 2                  # Maximum retries per step
        }

    def review_execution(self, execution_result: Dict[str, Any], iteration: int = 1) -> Dict[str, Any]:
        """
        Review execution results and determine next steps.

        Args:
            execution_result: Results from ExecuteAgent
            iteration: Current TPER iteration number

        Returns:
            Dict containing review decision and recommendations
        """
        print(f"\n🧪 ReviewAgent: Reviewing execution results...")
        print(f"-> Execution ID: {execution_result.get('execution_id', 'unknown')}")

        # Extract key metrics
        success_rate = execution_result.get('success_rate', 0)
        total_steps = execution_result.get('total_steps', 0)
        successful_steps = execution_result.get('successful_steps', 0)
        failed_steps = execution_result.get('failed_steps', 0)
        failed_step_ids = execution_result.get('failed_step_ids', [])

        print(f"-> Success Rate: {success_rate:.1%} ({successful_steps}/{total_steps} steps)")
        print(f"-> Failed Steps: {failed_steps} steps")

        # Analyze execution quality
        quality_analysis = self._analyze_execution_quality(execution_result)

        # Make decision based on results
        decision = self._make_decision(execution_result, iteration, quality_analysis)

        # Generate review report
        review_result = {
            "review_id": f"review_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            "execution_id": execution_result.get('execution_id'),
            "iteration": iteration,
            "success_rate": success_rate,
            "quality_score": quality_analysis['quality_score'],
            "decision": decision['action'],
            "reasoning": decision['reasoning'],
            "recommendations": decision['recommendations'],
            "final_assessment": self._generate_final_assessment(execution_result, quality_analysis),
            "should_continue": decision['action'] != 'complete',
            "next_steps": decision.get('next_steps', []),
            "reviewed_at": datetime.now().isoformat()
        }

        print(f"-> Decision: {decision['action'].upper()}")
        print(f"-> Reasoning: {decision['reasoning']}")

        self.review_history.append(review_result)
        return review_result

    def _analyze_execution_quality(self, execution_result: Dict[str, Any]) -> Dict[str, Any]:
        """
        Analyze the quality of execution results.

        Args:
            execution_result: Execution result to analyze

        Returns:
            Dict containing quality analysis
        """
        step_results = execution_result.get('step_results', [])

        # Quality factors
        factors = {
            'completion_rate': execution_result.get('success_rate', 0),
            'output_quality': self._assess_output_quality(step_results),
            'execution_efficiency': self._assess_execution_efficiency(execution_result),
            'error_severity': self._assess_error_severity(step_results)
        }

        # Calculate weighted quality score
        weights = {
            'completion_rate': 0.4,
            'output_quality': 0.3,
            'execution_efficiency': 0.2,
            'error_severity': 0.1
        }

        quality_score = sum(factors[key] * weights[key] for key in factors)

        return {
            "quality_score": quality_score,
            "factors": factors,
            "weights": weights,
            "assessment": self._get_quality_assessment(quality_score)
        }

    def _assess_output_quality(self, step_results: List[Dict[str, Any]]) -> float:
        """Assess quality of outputs from successful steps."""
        successful_results = [r for r in step_results if r['success']]

        if not successful_results:
            return 0.0

        quality_scores = []
        for result in successful_results:
            output = result.get('output', '')
            output_str = str(output).strip()

            # Simple output quality heuristics
            if not output_str:
                score = 0.0
            elif 'error' in output_str.lower() or 'failed' in output_str.lower():
                score = 0.3
            elif len(output_str) < 10:
                score = 0.6
            else:
                score = 1.0

            quality_scores.append(score)

        return sum(quality_scores) / len(quality_scores)

    def _assess_execution_efficiency(self, execution_result: Dict[str, Any]) -> float:
        """Assess execution efficiency based on timing and resource usage."""
        execution_time = execution_result.get('execution_time', 0)
        total_steps = execution_result.get('total_steps', 1)

        # Efficiency based on average time per step
        avg_time_per_step = execution_time / total_steps

        if avg_time_per_step < 1.0:
            return 1.0
        elif avg_time_per_step < 3.0:
            return 0.8
        elif avg_time_per_step < 5.0:
            return 0.6
        else:
            return 0.4

    def _assess_error_severity(self, step_results: List[Dict[str, Any]]) -> float:
        """Assess severity of errors in failed steps."""
        failed_results = [r for r in step_results if not r['success']]

        if not failed_results:
            return 1.0  # No errors = best score

        severity_scores = []
        for result in failed_results:
            error = result.get('error', '').lower()

            # Error severity classification
            if 'timeout' in error or 'network' in error:
                severity_scores.append(0.7)  # Temporary errors
            elif 'not found' in error or 'invalid' in error:
                severity_scores.append(0.5)  # Configuration errors
            elif 'permission' in error or 'access' in error:
                severity_scores.append(0.3)  # Access errors
            else:
                severity_scores.append(0.4)  # General errors

        # Average severity (higher score = less severe errors)
        return sum(severity_scores) / len(severity_scores)

    def _make_decision(self, execution_result: Dict[str, Any], iteration: int, quality_analysis: Dict[str, Any]) -> Dict[str, Any]:
        """
        Make decision about next steps based on execution results.

        Args:
            execution_result: Execution results to evaluate
            iteration: Current iteration number
            quality_analysis: Quality analysis results

        Returns:
            Dict containing decision and reasoning
        """
        success_rate = execution_result.get('success_rate', 0)
        quality_score = quality_analysis.get('quality_score', 0)
        failed_step_ids = execution_result.get('failed_step_ids', [])
        retry_count = execution_result.get('retry_count', 0)

        # Decision logic
        if success_rate >= self.decision_thresholds['success_rate_completion'] and quality_score > 0.7:
            return {
                "action": "complete",
                "reasoning": f"Task completed successfully with {success_rate:.1%} success rate and high quality score ({quality_score:.2f})",
                "recommendations": ["Task objectives have been met", "No further action required"],
                "next_steps": []
            }

        elif iteration >= self.decision_thresholds['max_iterations']:
            return {
                "action": "complete",
                "reasoning": f"Maximum iterations ({self.decision_thresholds['max_iterations']}) reached",
                "recommendations": ["Consider manual review of remaining issues", "Task partially completed"],
                "next_steps": []
            }

        elif success_rate >= self.decision_thresholds['success_rate_retry'] and retry_count < self.decision_thresholds['max_retries']:
            return {
                "action": "retry",
                "reasoning": f"Success rate ({success_rate:.1%}) indicates retry worthwhile for {len(failed_step_ids)} failed steps",
                "recommendations": [
                    f"Retry failed steps: {failed_step_ids}",
                    "Consider alternative tools if available"
                ],
                "next_steps": ["retry_failed_steps"]
            }

        elif success_rate < self.decision_thresholds['success_rate_retry'] and quality_score < 0.5:
            return {
                "action": "revise",
                "reasoning": f"Low success rate ({success_rate:.1%}) and quality score ({quality_score:.2f}) require plan revision",
                "recommendations": [
                    "Revise execution plan with alternative tools",
                    "Break down complex tasks into simpler steps",
                    "Consider different approach to task"
                ],
                "next_steps": ["revise_plan", "re_execute"]
            }

        else:
            return {
                "action": "complete",
                "reasoning": f"Task partially completed with {success_rate:.1%} success rate - best effort achieved",
                "recommendations": ["Review failed steps manually", "Consider task complexity vs available tools"],
                "next_steps": []
            }

    def _generate_final_assessment(self, execution_result: Dict[str, Any], quality_analysis: Dict[str, Any]) -> str:
        """Generate human-readable final assessment."""
        success_rate = execution_result.get('success_rate', 0)
        quality_score = quality_analysis.get('quality_score', 0)
        total_steps = execution_result.get('total_steps', 0)
        final_output = execution_result.get('final_output', '')

        assessment = f"Task execution completed with {success_rate:.1%} success rate across {total_steps} steps. "

        if quality_score > 0.8:
            assessment += "High-quality results achieved. "
        elif quality_score > 0.6:
            assessment += "Good quality results with minor issues. "
        else:
            assessment += "Results quality could be improved. "

        if final_output:
            assessment += f"Generated output: {final_output[:100]}..."

        return assessment

    def _get_quality_assessment(self, quality_score: float) -> str:
        """Get qualitative assessment of quality score."""
        if quality_score >= 0.9:
            return "excellent"
        elif quality_score >= 0.8:
            return "very_good"
        elif quality_score >= 0.7:
            return "good"
        elif quality_score >= 0.6:
            return "acceptable"
        elif quality_score >= 0.4:
            return "poor"
        else:
            return "very_poor"

    def get_review_summary(self, review_result: Dict[str, Any]) -> str:
        """
        Generate human-readable review summary.

        Args:
            review_result: Review result dictionary

        Returns:
            Formatted summary string
        """
        decision = review_result.get('decision', 'unknown')
        success_rate = review_result.get('success_rate', 0)
        quality_score = review_result.get('quality_score', 0)

        summary = f"Review Summary:\n"
        summary += f"Decision: {decision.upper()}\n"
        summary += f"Success Rate: {success_rate:.1%}\n"
        summary += f"Quality Score: {quality_score:.2f}\n"
        summary += f"\nReasoning: {review_result.get('reasoning', 'No reasoning provided')}\n"

        if review_result.get('recommendations'):
            summary += f"\nRecommendations:\n"
            for i, rec in enumerate(review_result['recommendations'], 1):
                summary += f"{i}. {rec}\n"

        return summary

    def should_continue_workflow(self, review_result: Dict[str, Any]) -> bool:
        """
        Determine if TPER workflow should continue.

        Args:
            review_result: Review result dictionary

        Returns:
            Boolean indicating if workflow should continue
        """
        return review_result.get('should_continue', False)

if __name__ == "__main__":
    # Test the ReviewAgent
    print("ReviewAgent module loaded successfully")
