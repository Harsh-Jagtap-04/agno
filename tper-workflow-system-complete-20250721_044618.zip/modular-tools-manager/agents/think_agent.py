"""
TPER ThinkAgent - Problem Analysis and User Clarification
Interprets user queries, asks clarifying questions, and provides structured problem breakdown.
"""

import json
import openai
from typing import Dict, List, Any, Optional
import os
from datetime import datetime

class ThinkAgent:
    def __init__(self, api_key: str = None):
        """Initialize ThinkAgent with OpenAI API key."""
        self.api_key = api_key or os.getenv('OPENAI_API_KEY')
        if not self.api_key:
            raise ValueError("OpenAI API key is required")

        openai.api_key = self.api_key
        self.clarification_count = 0
        self.max_clarifications = 3

    def analyze_task(self, user_input: str, clarifications: List[str] = None) -> Dict[str, Any]:
        """
        Analyze user input and provide structured problem breakdown.

        Args:
            user_input: Original user query
            clarifications: List of user responses to clarifying questions

        Returns:
            Dict containing analysis results and any follow-up questions
        """
        print(f"\n🧠 ThinkAgent: Analyzing task...")
        print(f"-> User Input: '{user_input}'")

        # Combine user input with clarifications
        full_context = user_input
        if clarifications:
            full_context += "\n\nAdditional context from clarifications:\n"
            full_context += "\n".join(f"- {clarification}" for clarification in clarifications)

        try:
            # Use OpenAI to analyze the task
            response = openai.ChatCompletion.create(
                model="gpt-3.5-turbo",
                messages=[
                    {
                        "role": "system",
                        "content": """You are a task analysis expert. Your job is to:
1. Analyze user requests for completeness
2. Ask up to 3 specific clarifying questions if information is missing
3. Provide structured problem breakdown when sufficient information is available

Always respond in JSON format with these fields:
- "needs_clarification": boolean
- "clarification_question": string (if needs_clarification is true)
- "analysis": dict with keys: "main_goal", "sub_tasks", "requirements", "constraints", "complexity", "estimated_tools"
- "confidence": float between 0.0 and 1.0"""
                    },
                    {
                        "role": "user",
                        "content": f"Analyze this task: {full_context}"
                    }
                ],
                temperature=0.7,
                max_tokens=500
            )

            result = json.loads(response.choices[0].message.content)

            if result.get("needs_clarification", False) and self.clarification_count < self.max_clarifications:
                print(f"-> Asking clarification: {result.get('clarification_question', 'Need more information')}")
                self.clarification_count += 1
                return {
                    "status": "needs_clarification",
                    "question": result.get("clarification_question", "Could you provide more details?"),
                    "analysis": None
                }
            else:
                print(f"-> Analysis complete with {result.get('confidence', 0.8):.1%} confidence")
                print(f"-> Main goal: {result['analysis']['main_goal']}")
                return {
                    "status": "complete",
                    "analysis": result["analysis"],
                    "confidence": result.get("confidence", 0.8)
                }

        except Exception as e:
            print(f"-> Error in analysis: {e}")
            # Fallback analysis
            return {
                "status": "complete",
                "analysis": {
                    "main_goal": user_input,
                    "sub_tasks": [user_input],
                    "requirements": ["Execute user request"],
                    "constraints": ["Use available tools"],
                    "complexity": "moderate",
                    "estimated_tools": ["general"]
                },
                "confidence": 0.6
            }

    def reset_clarifications(self):
        """Reset clarification counter for new tasks."""
        self.clarification_count = 0

    def get_task_breakdown(self, user_input: str, interactive: bool = True) -> Dict[str, Any]:
        """
        Get complete task breakdown, handling clarifications interactively if needed.

        Args:
            user_input: User's initial request
            interactive: Whether to ask for clarifications interactively

        Returns:
            Complete analysis dictionary
        """
        self.reset_clarifications()
        clarifications = []

        while True:
            result = self.analyze_task(user_input, clarifications)

            if result["status"] == "complete":
                return result["analysis"]

            elif result["status"] == "needs_clarification":
                if not interactive:
                    # If not interactive, proceed with current information
                    break

                print(f"\n❓ Clarification needed: {result['question']}")
                response = input("Your answer (or 'skip' to continue): ")

                if response.lower() in ['skip', 'no', 'continue']:
                    break

                clarifications.append(response)
            else:
                break

        # If we exit the loop, do final analysis with what we have
        final_result = self.analyze_task(user_input, clarifications)
        return final_result.get("analysis", {
            "main_goal": user_input,
            "sub_tasks": [user_input],
            "requirements": ["Execute user request"],
            "constraints": ["Use available tools"],
            "complexity": "moderate",
            "estimated_tools": ["general"]
        })

if __name__ == "__main__":
    # Test the ThinkAgent
    agent = ThinkAgent()

    test_queries = [
        "Calculate something",
        "Get current weather in Tokyo",
        "Find information about Python programming"
    ]

    for query in test_queries:
        print(f"\n{'='*60}")
        print(f"Testing query: {query}")
        result = agent.get_task_breakdown(query, interactive=False)
        print(f"Result: {json.dumps(result, indent=2)}")
