"""
Gradio Web Interface for TPER Workflow System
Modern web-based user interface with real-time TPER visualization.
"""

import gradio as gr
import json
import time
import threading
from datetime import datetime
from typing import Dict, Any, List, Tuple

class TPERGradioInterface:
    def __init__(self, orchestrator):
        """Initialize Gradio interface with TPER orchestrator."""
        self.orchestrator = orchestrator
        self.current_workflow = None
        self.workflow_history = []

        # Example prompts as requested
        self.example_prompts = [
            "Calculate 15 + 25 and save the result to a file",
            "Search for current information about artificial intelligence",
            "Get weather information for Tokyo, Japan",
            "Find Wikipedia article about machine learning",
            "Execute Python code to sum numbers 1 through 10",
            "Create a simple text file with today's date"
        ]

    def process_user_request(self, user_input: str, max_iterations: int) -> Tuple[str, str]:
        """
        Process user request through TPER workflow.

        Args:
            user_input: User's request
            max_iterations: Maximum iterations allowed

        Returns:
            Tuple of (response, tper_log)
        """
        if not user_input.strip():
            return "Please enter a request to process.", ""

        try:
            # Update orchestrator max iterations
            self.orchestrator.max_iterations = max_iterations

            # Execute TPER workflow
            workflow_result = self.orchestrator.execute_workflow(
                user_input, 
                interactive=False
            )

            # Store workflow
            self.current_workflow = workflow_result
            self.workflow_history.append(workflow_result)

            # Generate response
            response = self._format_workflow_response(workflow_result)

            # Generate TPER log
            tper_log = self._format_tper_log(workflow_result)

            return response, tper_log

        except Exception as e:
            error_msg = f"Error processing request: {str(e)}"
            return error_msg, f"Error: {error_msg}"

    def _format_workflow_response(self, workflow_result: Dict[str, Any]) -> str:
        """Format workflow result for main response area."""
        final_result = workflow_result.get('final_result', 'No output generated')
        success = workflow_result.get('success', False)
        iterations = len(workflow_result.get('iterations', []))
        total_time = workflow_result.get('total_time', 0)

        status_icon = "✅" if success else "⚠️"
        status_text = "Completed Successfully" if success else "Completed with Issues"

        response = f"""## {status_icon} {status_text}

**Result:** {final_result}

**Summary:**
- 🔄 Iterations: {iterations}
- ⏱️ Total Time: {total_time:.2f}s
- 📊 Status: {status_text}

---

The TPER system has processed your request through the complete Think → Plan → Execute → Review workflow. Check the TPER Log panel for detailed phase-by-phase execution information.
"""

        return response

    def _format_tper_log(self, workflow_result: Dict[str, Any]) -> str:
        """Format detailed TPER log for the log panel."""
        log_lines = []

        # Header
        log_lines.append("# 🔄 TPER Workflow Execution Log")
        log_lines.append(f"**Started:** {workflow_result.get('started_at', 'Unknown')}")
        log_lines.append(f"**Workflow ID:** {workflow_result.get('workflow_id', 'N/A')}")
        log_lines.append("")

        # Process each iteration
        iterations = workflow_result.get('iterations', [])
        for i, iteration in enumerate(iterations, 1):
            log_lines.append(f"## Iteration {i}")
            log_lines.append("")

            # Think Phase
            analysis = iteration.get('analysis', {})
            log_lines.append("### 🧠 Think Phase")
            log_lines.append(f"**Goal:** {analysis.get('main_goal', 'N/A')}")
            log_lines.append(f"**Complexity:** {analysis.get('complexity', 'N/A')}")
            log_lines.append(f"**Sub-tasks:** {len(analysis.get('sub_tasks', []))}")
            log_lines.append("")

            # Plan Phase
            plan = iteration.get('plan', {})
            log_lines.append("### 🧩 Plan Phase")
            log_lines.append(f"**Plan ID:** {plan.get('plan_id', 'N/A')}")
            log_lines.append(f"**Total Steps:** {plan.get('total_steps', 0)}")

            steps = plan.get('steps', [])
            if steps:
                log_lines.append("**Planned Steps:**")
                for step in steps:
                    log_lines.append(f"  {step.get('step_id', '?')}. {step.get('task', 'N/A')[:60]}... → {step.get('tool', 'N/A')}")
            log_lines.append("")

            # Execute Phase
            execution = iteration.get('execution_result', {})
            log_lines.append("### ⚙️ Execute Phase")
            log_lines.append(f"**Success Rate:** {execution.get('success_rate', 0):.1%}")
            log_lines.append(f"**Execution Time:** {execution.get('execution_time', 0):.2f}s")

            step_results = execution.get('step_results', [])
            if step_results:
                log_lines.append("**Step Results:**")
                for result in step_results:
                    status_icon = "✅" if result.get('success', False) else "❌"
                    step_id = result.get('step_id', '?')
                    tool = result.get('tool', 'N/A')
                    log_lines.append(f"  {status_icon} Step {step_id} ({tool})")

                    if result.get('success') and result.get('output'):
                        output_preview = str(result['output'])[:80]
                        log_lines.append(f"    Output: {output_preview}...")
                    elif not result.get('success') and result.get('error'):
                        log_lines.append(f"    Error: {result['error']}")
            log_lines.append("")

            # Review Phase
            review = iteration.get('review_result', {})
            log_lines.append("### 🧪 Review Phase")
            log_lines.append(f"**Decision:** {review.get('decision', 'N/A').upper()}")
            log_lines.append(f"**Quality Score:** {review.get('quality_score', 0):.2f}")
            log_lines.append(f"**Reasoning:** {review.get('reasoning', 'N/A')}")

            recommendations = review.get('recommendations', [])
            if recommendations:
                log_lines.append("**Recommendations:**")
                for rec in recommendations:
                    log_lines.append(f"  • {rec}")
            log_lines.append("")
            log_lines.append("---")
            log_lines.append("")

        # Final Summary
        log_lines.append("## 📊 Final Summary")
        log_lines.append(f"**Total Iterations:** {len(iterations)}")
        log_lines.append(f"**Total Time:** {workflow_result.get('total_time', 0):.2f}s")
        log_lines.append(f"**Success:** {'Yes' if workflow_result.get('success', False) else 'Partial'}")
        log_lines.append(f"**Completed:** {workflow_result.get('completed_at', 'Unknown')}")

        return "\n".join(log_lines)

    def get_system_status(self) -> str:
        """Get current system status information."""
        tools_status = self.orchestrator.get_tools_status()
        available_tools = [name for name, status in tools_status.items() 
                         if status.get('available', False)]

        status_info = f"""## 🔧 System Status

**Available Tools:** {len(available_tools)}/{len(tools_status)}
{chr(10).join(f"• {tool}" for tool in available_tools)}

**Configuration:**
• Max Iterations: {self.orchestrator.max_iterations}
• Console Logging: {'Enabled' if self.orchestrator.logger.use_colors else 'Disabled'}

**Last Updated:** {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}
"""

        return status_info

    def create_interface(self) -> gr.Blocks:
        """Create the Gradio interface."""
        with gr.Blocks(
            title="TPER Workflow 2.0 System",
            theme=gr.themes.Soft(),
            css="""
            .container { max-width: 1200px; margin: auto; }
            .tper-header { text-align: center; padding: 20px; }
            .tper-log { font-family: monospace; }
            """
        ) as interface:

            # Header
            gr.HTML("""
            <div class="tper-header">
                <h1>🔄 TPER Workflow 2.0 System</h1>
                <p><strong>Think → Plan → Execute → Review</strong></p>
                <p>AI Agent Orchestration Platform</p>
            </div>
            """)

            with gr.Row():
                # Left column (30%) - Chat Interface
                with gr.Column(scale=3):
                    gr.HTML("<h3>💬 Chat Interface</h3>")

                    # Chat input
                    user_input = gr.Textbox(
                        label="Enter your request",
                        placeholder="What would you like the TPER system to help you with?",
                        lines=3
                    )

                    # Controls
                    with gr.Row():
                        submit_btn = gr.Button("🚀 Process Request", variant="primary")
                        clear_btn = gr.Button("🗑️ Clear", variant="secondary")

                    # Iteration control
                    max_iterations = gr.Slider(
                        minimum=1,
                        maximum=10,
                        value=5,
                        step=1,
                        label="Max Iterations",
                        info="Maximum TPER workflow iterations"
                    )

                    # Example prompts
                    gr.HTML("<h4>📝 Example Prompts</h4>")
                    example_buttons = []
                    for i, prompt in enumerate(self.example_prompts):
                        btn = gr.Button(f"{i+1}. {prompt[:50]}...", size="sm")
                        example_buttons.append(btn)

                    # Response area
                    response_output = gr.Markdown(
                        label="Response",
                        value="Welcome to the TPER Workflow System! Enter a request above to get started."
                    )

                # Right column (70%) - TPER Logs
                with gr.Column(scale=7):
                    gr.HTML("<h3>📊 TPER Execution Log</h3>")

                    tper_log_output = gr.Markdown(
                        value="TPER execution details will appear here after processing a request...",
                        elem_classes=["tper-log"]
                    )

            # System status (bottom)
            with gr.Accordion("🔧 System Status", open=False):
                system_status = gr.Markdown(self.get_system_status())
                refresh_status_btn = gr.Button("🔄 Refresh Status")

            # Event handlers
            def process_request(user_input_text, max_iter):
                if not user_input_text.strip():
                    return "Please enter a request to process.", "No request provided."
                return self.process_user_request(user_input_text, max_iter)

            def clear_interface():
                return "", "Interface cleared. Enter a new request to begin.", "TPER execution details will appear here..."

            def set_example_prompt(prompt_text):
                return prompt_text

            def refresh_status():
                return self.get_system_status()

            # Connect events
            submit_btn.click(
                process_request,
                inputs=[user_input, max_iterations],
                outputs=[response_output, tper_log_output]
            )

            clear_btn.click(
                clear_interface,
                outputs=[user_input, response_output, tper_log_output]
            )

            # Example prompt buttons
            for i, btn in enumerate(example_buttons):
                btn.click(
                    lambda prompt=self.example_prompts[i]: prompt,
                    outputs=[user_input]
                )

            refresh_status_btn.click(
                refresh_status,
                outputs=[system_status]
            )

        return interface

def launch_gradio_interface(orchestrator, **kwargs):
    """
    Launch the Gradio web interface.

    Args:
        orchestrator: TPER orchestrator instance
        **kwargs: Additional Gradio launch arguments
    """
    # Create interface
    tper_interface = TPERGradioInterface(orchestrator)
    interface = tper_interface.create_interface()

    # Default launch settings
    launch_settings = {
        "server_name": "127.0.0.1",
        "server_port": 7860,
        "share": False,
        "debug": False,
        "show_tips": False,
        **kwargs
    }

    print(f"🌐 Starting Gradio interface at http://{launch_settings['server_name']}:{launch_settings['server_port']}")
    print("   Press Ctrl+C to stop the server")

    # Launch interface
    interface.launch(**launch_settings)

if __name__ == "__main__":
    # Test interface (requires orchestrator)
    print("Gradio UI module loaded successfully")
    print("Use launch_gradio_interface(orchestrator) to start the web interface")
