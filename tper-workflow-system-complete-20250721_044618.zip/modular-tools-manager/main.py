#!/usr/bin/env python3
"""
TPER Workflow System - Main Entry Point
Command-line interface for the Think → Plan → Execute → Review workflow system.
"""

import os
import sys
import argparse
import yaml
from datetime import datetime

# Add project root to path
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from orchestrator.tper_orchestrator import TPEROrchestrator
from orchestrator.console_logger import ConsoleLogger

def load_config(config_path: str = "config.yaml") -> dict:
    """Load system configuration from YAML file."""
    if os.path.exists(config_path):
        try:
            with open(config_path, 'r') as f:
                return yaml.safe_load(f)
        except Exception as e:
            print(f"⚠️ Error loading config: {e}")

    # Return default config
    return {
        "system": {"max_iterations": 5, "enable_console_logs": True},
        "agents": {},
        "tools": {}
    }

def setup_environment():
    """Set up environment and check dependencies."""
    # Check for OpenAI API key
    api_key = os.getenv('OPENAI_API_KEY')
    if not api_key:
        print("⚠️ Warning: OPENAI_API_KEY environment variable not set")
        print("Set it with: export OPENAI_API_KEY='your_api_key_here'")
        print("The system will use a placeholder key for demonstration.\n")
        return "demo_key_placeholder"
    return api_key

def run_interactive_console(orchestrator: TPEROrchestrator):
    """Run interactive console mode."""
    logger = ConsoleLogger()

    logger.print_header("TPER WORKFLOW SYSTEM - INTERACTIVE CONSOLE")
    print("💡 Enter your requests and watch the TPER workflow in action!")
    print("   Type 'help' for available commands, 'quit' to exit.\n")

    while True:
        try:
            user_input = input("🎯 Enter your request: ").strip()

            if not user_input:
                continue
            elif user_input.lower() in ['quit', 'exit', 'q']:
                print("👋 Goodbye!")
                break
            elif user_input.lower() == 'help':
                show_help()
                continue
            elif user_input.lower() == 'tools':
                show_tools(orchestrator)
                continue
            elif user_input.lower() == 'status':
                show_status(orchestrator)
                continue

            # Execute TPER workflow
            print(f"\n🚀 Starting TPER workflow for: '{user_input}'")
            result = orchestrator.execute_workflow(user_input, interactive=True)

            print(f"\n{orchestrator.get_workflow_summary(result)}")
            print("\n" + "="*60 + "\n")

        except KeyboardInterrupt:
            print("\n\n👋 Goodbye!")
            break
        except Exception as e:
            print(f"\n❌ Error: {e}\n")

def show_help():
    """Show help information."""
    help_text = """
🔧 Available Commands:
  • help - Show this help message
  • tools - Show available tools status
  • status - Show system status
  • quit/exit/q - Exit the console

📝 Example Requests:
  • "Calculate 15 + 25"
  • "Search for information about Python programming"
  • "Get current weather in Tokyo"
  • "Write hello world to a file"
  • "Find information about machine learning"

🔄 TPER Process:
  🧠 Think - Analyzes your request and asks clarifying questions
  🧩 Plan - Creates execution plan using available tools
  ⚙️ Execute - Runs the plan step by step
  🧪 Review - Evaluates results and decides next steps

The system will guide you through each phase with detailed console output.
"""
    print(help_text)

def show_tools(orchestrator: TPEROrchestrator):
    """Show available tools status."""
    print("\n🔧 Available Tools:")

    tools_status = orchestrator.get_tools_status()
    for tool_name, status in tools_status.items():
        if status.get('available', False):
            print(f"   ✅ {tool_name}: Ready")
        else:
            reason = status.get('reason', 'Unknown error')
            print(f"   ❌ {tool_name}: {reason}")

    print(f"\nTotal: {sum(1 for s in tools_status.values() if s.get('available', False))}/{len(tools_status)} tools available\n")

def show_status(orchestrator: TPEROrchestrator):
    """Show system status."""
    print("\n📊 System Status:")
    print(f"   🔧 Available tools: {len(orchestrator.get_available_tools())}")
    print(f"   🔄 Max iterations: {orchestrator.max_iterations}")
    print(f"   📝 Console logging: {'Enabled' if orchestrator.logger.use_colors else 'Disabled'}")
    print(f"   ⏰ System time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print()

def main():
    """Main entry point."""
    parser = argparse.ArgumentParser(
        description="TPER Workflow System - AI Agent Orchestration Framework",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python main.py --task "Calculate 15 + 25"
  python main.py --console
  python main.py --ui

The TPER system orchestrates AI agents through four phases:
🧠 Think → 🧩 Plan → ⚙️ Execute → 🧪 Review
        """
    )

    parser.add_argument(
        '--task', '-t',
        type=str,
        help='Execute a specific task using TPER workflow'
    )

    parser.add_argument(
        '--console', '-c',
        action='store_true',
        help='Launch interactive console mode'
    )

    parser.add_argument(
        '--ui', '-u',
        action='store_true', 
        help='Launch Gradio web interface'
    )

    parser.add_argument(
        '--config',
        type=str,
        default='config.yaml',
        help='Path to configuration file (default: config.yaml)'
    )

    parser.add_argument(
        '--no-colors',
        action='store_true',
        help='Disable colored console output'
    )

    parser.add_argument(
        '--max-iterations',
        type=int,
        default=5,
        help='Maximum TPER iterations (default: 5)'
    )

    args = parser.parse_args()

    # Setup
    api_key = setup_environment()
    config = load_config(args.config)

    # Initialize orchestrator
    try:
        orchestrator = TPEROrchestrator(
            openai_api_key=api_key,
            enable_console_logs=not args.no_colors,
            max_iterations=args.max_iterations
        )
    except Exception as e:
        print(f"❌ Failed to initialize TPER system: {e}")
        print("   Please check your configuration and try again.")
        return 1

    # Handle commands
    if args.ui:
        # Launch Gradio interface
        try:
            from gradio_ui import launch_gradio_interface
            print("🌐 Launching Gradio web interface...")
            launch_gradio_interface(orchestrator)
        except ImportError:
            print("❌ Gradio not installed. Install with: pip install gradio>=4.0.0")
            return 1
        except Exception as e:
            print(f"❌ Failed to launch web interface: {e}")
            return 1

    elif args.console:
        # Launch interactive console
        run_interactive_console(orchestrator)

    elif args.task:
        # Execute single task
        print(f"🚀 Executing task: '{args.task}'")
        result = orchestrator.execute_workflow(args.task, interactive=False)
        print(f"\n{orchestrator.get_workflow_summary(result)}")

    else:
        # Default: show help and launch console
        print("🎯 TPER Workflow System")
        print("=" * 50)
        print("No specific command provided. Launching interactive console...")
        print("Use --help to see all available options.\n")
        run_interactive_console(orchestrator)

    return 0

if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\n👋 Goodbye!")
        sys.exit(0)
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")
        sys.exit(1)
