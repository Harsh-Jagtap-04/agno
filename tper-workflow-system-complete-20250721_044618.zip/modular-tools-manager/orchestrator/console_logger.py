"""
Console Logger for TPER Workflow System
Provides formatted console output with visual flow diagrams and colored logging.
"""

import json
from typing import Dict, List, Any, Optional
from datetime import datetime
import sys

class ConsoleLogger:
    def __init__(self, use_colors: bool = True):
        """Initialize console logger with color options."""
        self.use_colors = use_colors
        self.iteration_count = 0

        # ANSI color codes
        self.colors = {
            'red': '\033[91m',
            'green': '\033[92m',
            'yellow': '\033[93m',
            'blue': '\033[94m',
            'magenta': '\033[95m',
            'cyan': '\033[96m',
            'white': '\033[97m',
            'bold': '\033[1m',
            'underline': '\033[4m',
            'reset': '\033[0m'
        }

        # Phase configurations
        self.phase_config = {
            'think': {'emoji': '🧠', 'color': 'cyan', 'name': 'Think'},
            'plan': {'emoji': '🧩', 'color': 'yellow', 'name': 'Plan'},
            'execute': {'emoji': '⚙️', 'color': 'green', 'name': 'Execute'},
            'review': {'emoji': '🧪', 'color': 'magenta', 'name': 'Review'}
        }

    def colorize(self, text: str, color: str) -> str:
        """Apply color formatting to text if colors are enabled."""
        if not self.use_colors:
            return text

        color_code = self.colors.get(color, '')
        reset_code = self.colors.get('reset', '')
        return f"{color_code}{text}{reset_code}"

    def print_separator(self, char: str = '=', length: int = 70):
        """Print a separator line."""
        print(self.colorize(char * length, 'blue'))

    def print_header(self, title: str):
        """Print a formatted header."""
        self.print_separator()
        centered_title = title.center(70)
        print(self.colorize(centered_title, 'bold'))
        self.print_separator()

    def log_tper_start(self, user_input: str):
        """Log the start of a TPER workflow."""
        self.iteration_count = 0
        self.print_header("TPER WORKFLOW 2.0 - STARTED")
        print(f"🎯 User Request: {self.colorize(user_input, 'white')}")
        print(f"⏰ Started at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
        print()

    def log_iteration_start(self, iteration: int):
        """Log the start of a new TPER iteration."""
        self.iteration_count = iteration
        print()
        self.print_separator('─', 70)
        iteration_text = f"ITERATION {iteration}"
        print(self.colorize(iteration_text.center(70), 'bold'))
        self.print_separator('─', 70)

    def log_phase_start(self, phase: str, description: str = ""):
        """Log the start of a TPER phase."""
        config = self.phase_config.get(phase.lower(), {'emoji': '🔄', 'color': 'white', 'name': phase.title()})

        phase_header = f"Phase: {config['name']} {config['emoji']}"
        print()
        print(self.colorize(phase_header, config['color']))

        if description:
            print(f"-> {description}")

    def log_think_phase(self, user_input: str, clarification: str = None, analysis: Dict[str, Any] = None):
        """Log Think phase activities."""
        self.log_phase_start('think', 'Analyzing user request and gathering requirements')

        print(f"-> User Input: '{self.colorize(user_input, 'white')}'")

        if clarification:
            print(f"-> Asking clarification: {self.colorize(clarification, 'yellow')}")

        if analysis:
            print(f"-> Problem breakdown generated:")
            print(f"   Main Goal: {analysis.get('main_goal', 'N/A')}")
            print(f"   Complexity: {analysis.get('complexity', 'N/A')}")
            print(f"   Sub-tasks: {len(analysis.get('sub_tasks', []))}")

    def log_plan_phase(self, available_tools: List[str], plan: Dict[str, Any]):
        """Log Plan phase activities."""
        self.log_phase_start('plan', 'Creating execution plan and mapping tools')

        print(f"-> Available Tools: {self.colorize(str(available_tools), 'cyan')}")

        if plan and 'steps' in plan:
            print(f"-> Created {len(plan['steps'])} execution steps:")
            for step in plan['steps']:
                tool_name = step.get('tool', 'unknown')
                task_preview = step.get('task', '')[:50]
                if len(step.get('task', '')) > 50:
                    task_preview += '...'
                print(f"   Step {step.get('step_id', '?')}: {task_preview} -> {self.colorize(tool_name, 'green')}")

    def log_execute_phase(self, execution_result: Dict[str, Any]):
        """Log Execute phase activities."""
        self.log_phase_start('execute', 'Executing planned tasks using available tools')

        step_results = execution_result.get('step_results', [])

        for result in step_results:
            step_id = result.get('step_id', '?')
            tool_name = result.get('tool', 'unknown')
            success = result.get('success', False)

            status_icon = '✅' if success else '❌'
            status_color = 'green' if success else 'red'

            print(f"-> Calling: {self.colorize(tool_name, 'cyan')} (Step {step_id})")

            if result.get('input'):
                input_preview = str(result['input'])[:60]
                if len(str(result['input'])) > 60:
                    input_preview += '...'
                print(f"   Input: {input_preview}")

            if success and result.get('output'):
                output_preview = str(result['output'])[:80]
                if len(str(result['output'])) > 80:
                    output_preview += '...'
                print(f"   Output: {output_preview}")
            elif not success and result.get('error'):
                print(f"   Error: {self.colorize(result['error'], 'red')}")

            execution_time = result.get('execution_time', 0)
            print(f"   {status_icon} Step {step_id} {self.colorize('completed' if success else 'failed', status_color)} in {execution_time:.2f}s")
            print()

        # Summary
        success_rate = execution_result.get('success_rate', 0)
        total_time = execution_result.get('execution_time', 0)
        print(f"-> Execution Summary: {success_rate:.1%} success rate in {total_time:.2f}s")

    def log_review_phase(self, review_result: Dict[str, Any]):
        """Log Review phase activities."""
        self.log_phase_start('review', 'Evaluating results and determining next steps')

        success_rate = review_result.get('success_rate', 0)
        quality_score = review_result.get('quality_score', 0)
        decision = review_result.get('decision', 'unknown')

        print(f"-> Success Rate: {self.colorize(f'{success_rate:.1%}', 'cyan')}")
        print(f"-> Quality Score: {self.colorize(f'{quality_score:.2f}', 'cyan')}")
        print(f"-> Decision: {self.colorize(decision.upper(), 'yellow')}")
        print(f"-> Reasoning: {review_result.get('reasoning', 'No reasoning provided')}")

        if review_result.get('recommendations'):
            print(f"-> Recommendations:")
            for i, rec in enumerate(review_result['recommendations'], 1):
                print(f"   {i}. {rec}")

    def log_final_result(self, final_output: str, total_iterations: int, success: bool):
        """Log the final result of the TPER workflow."""
        print()
        self.print_separator('═', 70)

        status = "COMPLETED ✅" if success else "COMPLETED WITH ISSUES ⚠️"
        status_color = 'green' if success else 'yellow'

        print(self.colorize(status.center(70), status_color))
        self.print_separator('═', 70)

        print(f"🔄 Total Iterations: {total_iterations}")
        print(f"⏰ Completed at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

        if final_output:
            print(f"\n📋 Final Output:")
            print(self.colorize(final_output, 'white'))

        print()
        self.print_separator('═', 70)

    def log_error(self, error_message: str, phase: str = None):
        """Log an error message."""
        error_prefix = f"❌ {phase.upper()} ERROR:" if phase else "❌ ERROR:"
        print(self.colorize(f"{error_prefix} {error_message}", 'red'))

    def log_warning(self, warning_message: str):
        """Log a warning message."""
        print(self.colorize(f"⚠️ WARNING: {warning_message}", 'yellow'))

    def log_info(self, info_message: str):
        """Log an informational message."""
        print(f"ℹ️ INFO: {info_message}")

    def log_success(self, success_message: str):
        """Log a success message."""
        print(self.colorize(f"✅ SUCCESS: {success_message}", 'green'))

    def log_debug(self, debug_message: str, data: Any = None):
        """Log debug information."""
        print(self.colorize(f"🐛 DEBUG: {debug_message}", 'magenta'))
        if data:
            print(f"   Data: {json.dumps(data, indent=2) if isinstance(data, (dict, list)) else str(data)}")

    def log_tool_status(self, tools_status: Dict[str, Any]):
        """Log the status of available tools."""
        print("\n🔧 Tools Status:")

        for tool_name, status in tools_status.items():
            if status.get('available', False):
                print(f"   ✅ {self.colorize(tool_name, 'green')}: Ready")
            else:
                reason = status.get('reason', 'Unknown error')
                print(f"   ❌ {self.colorize(tool_name, 'red')}: {reason}")

    def create_flow_diagram(self, phases_completed: List[str], current_phase: str = None) -> str:
        """Create a visual flow diagram showing TPER progress."""
        phases = ['think', 'plan', 'execute', 'review']
        diagram_parts = []

        for i, phase in enumerate(phases):
            config = self.phase_config[phase]

            if phase in phases_completed:
                status = self.colorize(f"{config['emoji']} {config['name']} ✅", 'green')
            elif phase == current_phase:
                status = self.colorize(f"{config['emoji']} {config['name']} 🔄", config['color'])
            else:
                status = f"{config['emoji']} {config['name']} ⏸️"

            diagram_parts.append(status)

            # Add arrow except for last element
            if i < len(phases) - 1:
                arrow = ' → ' if phase in phases_completed or phase == current_phase else ' ⋯ '
                diagram_parts.append(arrow)

        return ''.join(diagram_parts)

    def enable_colors(self):
        """Enable color output."""
        self.use_colors = True

    def disable_colors(self):
        """Disable color output."""
        self.use_colors = False

if __name__ == "__main__":
    # Test the ConsoleLogger
    logger = ConsoleLogger()

    # Test basic logging
    logger.log_tper_start("Test the console logging system")
    logger.log_iteration_start(1)

    # Test phase logging
    logger.log_think_phase("Calculate 15 + 25", analysis={
        'main_goal': 'Perform calculation',
        'complexity': 'simple',
        'sub_tasks': ['calculate', 'display result']
    })

    logger.log_plan_phase(['calculator', 'python'], {
        'steps': [
            {'step_id': 1, 'task': 'Calculate 15 + 25', 'tool': 'calculator'}
        ]
    })

    logger.log_final_result("15 + 25 = 40", 1, True)

    print("\nConsoleLogger module loaded successfully")
