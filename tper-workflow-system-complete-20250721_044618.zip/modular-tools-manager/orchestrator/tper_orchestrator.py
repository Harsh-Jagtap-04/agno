"""
TPER Orchestrator - Main Workflow Coordination
Manages the Think → Plan → Execute → Review workflow cycle.
"""

import sys
import os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from typing import Dict, List, Any, Optional
from datetime import datetime
import time

from agents.think_agent import ThinkAgent
from agents.plan_agent import PlanAgent
from agents.execute_agent import ExecuteAgent
from agents.review_agent import ReviewAgent
from orchestrator.console_logger import ConsoleLogger
from tools.tools_manager import ToolsManager

class TPEROrchestrator:
    def __init__(self, openai_api_key: str = None, enable_console_logs: bool = True, max_iterations: int = 5):
        """
        Initialize TPER Orchestrator.

        Args:
            openai_api_key: OpenAI API key for ThinkAgent
            enable_console_logs: Whether to enable detailed console logging
            max_iterations: Maximum number of TPER iterations
        """
        self.max_iterations = max_iterations
        self.current_iteration = 0
        self.workflow_history = []

        # Initialize console logger
        self.logger = ConsoleLogger(use_colors=enable_console_logs)

        # Initialize tools manager
        self.tools_manager = ToolsManager()

        # Initialize agents
        try:
            self.think_agent = ThinkAgent(openai_api_key)
            self.plan_agent = PlanAgent(self.tools_manager)
            self.execute_agent = ExecuteAgent(self.tools_manager)
            self.review_agent = ReviewAgent()

            self.logger.log_success("All TPER agents initialized successfully")

        except Exception as e:
            self.logger.log_error(f"Failed to initialize agents: {e}")
            raise

        # Log tools status
        tools_status = self.tools_manager.get_tools_status()
        self.logger.log_tool_status(tools_status)

    def execute_workflow(self, user_input: str, interactive: bool = True) -> Dict[str, Any]:
        """
        Execute the complete TPER workflow for a user request.

        Args:
            user_input: User's request or task description
            interactive: Whether to allow interactive clarifications

        Returns:
            Dict containing complete workflow results
        """
        self.logger.log_tper_start(user_input)

        workflow_start_time = time.time()
        workflow_result = {
            "user_input": user_input,
            "workflow_id": f"workflow_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            "iterations": [],
            "final_result": None,
            "success": False,
            "total_time": 0,
            "started_at": datetime.now().isoformat()
        }

        current_analysis = None
        current_plan = None

        # Main TPER loop
        for iteration in range(1, self.max_iterations + 1):
            self.current_iteration = iteration
            self.logger.log_iteration_start(iteration)

            iteration_result = self._execute_single_iteration(
                user_input, 
                current_analysis, 
                current_plan,
                iteration,
                interactive and iteration == 1  # Only interactive on first iteration
            )

            workflow_result["iterations"].append(iteration_result)

            # Check if workflow should continue
            if not iteration_result.get("should_continue", False):
                workflow_result["success"] = iteration_result["review_result"]["decision"] == "complete"
                workflow_result["final_result"] = iteration_result["execution_result"]["final_output"]
                break

            # Prepare for next iteration
            if iteration_result["review_result"]["decision"] == "revise":
                # Plan needs revision
                current_analysis = iteration_result["analysis"]
                current_plan = None
            else:
                # Keep current plan for retry
                current_plan = iteration_result["plan"]

        # Calculate total time
        workflow_result["total_time"] = time.time() - workflow_start_time
        workflow_result["completed_at"] = datetime.now().isoformat()

        # Log final result
        final_output = workflow_result.get("final_result", "No output generated")
        self.logger.log_final_result(final_output, iteration, workflow_result["success"])

        self.workflow_history.append(workflow_result)
        return workflow_result

    def _execute_single_iteration(self, user_input: str, analysis: Dict[str, Any] = None, 
                                 plan: Dict[str, Any] = None, iteration: int = 1, 
                                 interactive: bool = True) -> Dict[str, Any]:
        """
        Execute a single TPER iteration.

        Args:
            user_input: User's original request
            analysis: Existing analysis from previous iteration
            plan: Existing plan from previous iteration
            iteration: Current iteration number
            interactive: Whether to allow interactive clarifications

        Returns:
            Dict containing iteration results
        """
        iteration_start_time = time.time()

        # THINK Phase
        if not analysis:
            analysis = self._execute_think_phase(user_input, interactive)

        # PLAN Phase
        if not plan or iteration > 1:
            plan = self._execute_plan_phase(analysis)

        # EXECUTE Phase
        execution_result = self._execute_execute_phase(plan)

        # REVIEW Phase
        review_result = self._execute_review_phase(execution_result, iteration)

        # Determine next steps based on review
        should_continue = self._should_continue_workflow(review_result, execution_result)

        iteration_result = {
            "iteration": iteration,
            "analysis": analysis,
            "plan": plan,
            "execution_result": execution_result,
            "review_result": review_result,
            "should_continue": should_continue,
            "iteration_time": time.time() - iteration_start_time,
            "timestamp": datetime.now().isoformat()
        }

        return iteration_result

    def _execute_think_phase(self, user_input: str, interactive: bool = True) -> Dict[str, Any]:
        """Execute the Think phase."""
        try:
            analysis = self.think_agent.get_task_breakdown(user_input, interactive)
            self.logger.log_think_phase(user_input, analysis=analysis)
            return analysis

        except Exception as e:
            self.logger.log_error(f"Think phase failed: {e}", "THINK")
            # Return fallback analysis
            return {
                "main_goal": user_input,
                "sub_tasks": [user_input],
                "requirements": ["Complete user request"],
                "constraints": ["Use available tools"],
                "complexity": "moderate",
                "estimated_tools": ["general"]
            }

    def _execute_plan_phase(self, analysis: Dict[str, Any]) -> Dict[str, Any]:
        """Execute the Plan phase."""
        try:
            available_tools = list(self.tools_manager.get_available_tools().keys())
            plan = self.plan_agent.create_plan(analysis)
            self.logger.log_plan_phase(available_tools, plan)
            return plan

        except Exception as e:
            self.logger.log_error(f"Plan phase failed: {e}", "PLAN")
            # Return fallback plan
            return {
                "plan_id": f"fallback_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
                "original_goal": analysis.get('main_goal', ''),
                "steps": [{
                    "step_id": 1,
                    "task": analysis.get('main_goal', ''),
                    "tool": "duckduckgo",
                    "priority": "high"
                }],
                "total_steps": 1
            }

    def _execute_execute_phase(self, plan: Dict[str, Any]) -> Dict[str, Any]:
        """Execute the Execute phase."""
        try:
            execution_result = self.execute_agent.execute_plan(plan)
            self.logger.log_execute_phase(execution_result)
            return execution_result

        except Exception as e:
            self.logger.log_error(f"Execute phase failed: {e}", "EXECUTE")
            # Return fallback execution result
            return {
                "plan_id": plan.get('plan_id'),
                "status": "failed",
                "success_rate": 0.0,
                "step_results": [],
                "final_output": f"Execution failed: {e}",
                "error": str(e)
            }

    def _execute_review_phase(self, execution_result: Dict[str, Any], iteration: int) -> Dict[str, Any]:
        """Execute the Review phase."""
        try:
            review_result = self.review_agent.review_execution(execution_result, iteration)
            self.logger.log_review_phase(review_result)
            return review_result

        except Exception as e:
            self.logger.log_error(f"Review phase failed: {e}", "REVIEW")
            # Return fallback review result
            return {
                "decision": "complete",
                "reasoning": f"Review failed, completing with current results: {e}",
                "success_rate": execution_result.get('success_rate', 0),
                "should_continue": False
            }

    def _should_continue_workflow(self, review_result: Dict[str, Any], execution_result: Dict[str, Any]) -> bool:
        """Determine if workflow should continue based on review results."""
        # Don't continue if at max iterations
        if self.current_iteration >= self.max_iterations:
            return False

        # Continue based on review decision
        decision = review_result.get("decision", "complete")
        return decision in ["retry", "revise"]

    def get_workflow_summary(self, workflow_result: Dict[str, Any]) -> str:
        """
        Generate human-readable workflow summary.

        Args:
            workflow_result: Complete workflow result

        Returns:
            Formatted summary string
        """
        iterations_count = len(workflow_result.get("iterations", []))
        success = workflow_result.get("success", False)
        total_time = workflow_result.get("total_time", 0)
        final_result = workflow_result.get("final_result", "No output generated")

        summary = f"TPER Workflow Summary\n"
        summary += f"{'='*50}\n"
        summary += f"Status: {'SUCCESS' if success else 'PARTIAL COMPLETION'}\n"
        summary += f"Iterations: {iterations_count}/{self.max_iterations}\n"
        summary += f"Total Time: {total_time:.2f}s\n"
        summary += f"\nFinal Output:\n{final_result}\n"

        if workflow_result.get("iterations"):
            last_iteration = workflow_result["iterations"][-1]
            last_review = last_iteration.get("review_result", {})

            summary += f"\nFinal Decision: {last_review.get('decision', 'unknown').upper()}\n"
            summary += f"Success Rate: {last_review.get('success_rate', 0):.1%}\n"

        return summary

    def reset_workflow(self):
        """Reset orchestrator state for new workflow."""
        self.current_iteration = 0
        self.think_agent.reset_clarifications()

    def get_available_tools(self) -> List[str]:
        """Get list of available tool names."""
        return list(self.tools_manager.get_available_tools().keys())

    def get_tools_status(self) -> Dict[str, Any]:
        """Get detailed status of all tools."""
        return self.tools_manager.get_tools_status()

if __name__ == "__main__":
    # Test the TPER Orchestrator
    import os

    # Example usage
    api_key = os.getenv('OPENAI_API_KEY')
    if not api_key:
        print("⚠️ Warning: OPENAI_API_KEY not found in environment variables")
        print("Set your API key with: export OPENAI_API_KEY='your_key_here'")
        api_key = "your_openai_api_key_here"  # Fallback for testing

    try:
        orchestrator = TPEROrchestrator(openai_api_key=api_key)

        # Test workflow
        test_request = "Calculate 15 + 25 and tell me about the result"
        result = orchestrator.execute_workflow(test_request, interactive=False)

        print("\n" + orchestrator.get_workflow_summary(result))

    except Exception as e:
        print(f"❌ Error testing orchestrator: {e}")

    print("\nTPEROrchestrator module loaded successfully")
