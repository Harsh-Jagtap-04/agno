"""
Formatting Agent - Text and Data Formatting
Agent-based tool for formatting and processing various text and data formats.
"""

from typing import Any, Dict, Union, List
import json
import re
from datetime import datetime

class FormattingAgentTool:
    def __init__(self):
        """Initialize Formatting Agent Tool."""
        self.name = "formatting_agent"
        self.description = "Formats and processes text, data, and various content types"
        self.input_format = "string"
        self.output_format = "string"
        self.capabilities = [
            "text formatting and styling",
            "data structure formatting", 
            "JSON/CSV formatting",
            "markdown generation",
            "report formatting",
            "code formatting"
        ]

    def execute(self, command: str) -> str:
        """
        Execute formatting operation.

        Args:
            command: Formatting command with content

        Returns:
            Formatted content
        """
        try:
            operation, content = self._parse_formatting_command(command)

            if operation == "json":
                return self._format_json(content)
            elif operation == "markdown":
                return self._format_markdown(content)
            elif operation == "table":
                return self._format_table(content)
            elif operation == "report":
                return self._format_report(content)
            elif operation == "code":
                return self._format_code(content)
            elif operation == "list":
                return self._format_list(content)
            else:
                return self._format_general(command)

        except Exception as e:
            return f"Formatting error: {str(e)}"

    def _parse_formatting_command(self, command: str) -> tuple:
        """Parse formatting command."""
        command_lower = command.lower()

        if "json" in command_lower:
            content = command.replace("json", "", 1).strip()
            return "json", content
        elif "markdown" in command_lower or "md" in command_lower:
            content = command.replace("markdown", "").replace("md", "").strip()
            return "markdown", content
        elif "table" in command_lower:
            content = command.replace("table", "").strip()
            return "table", content
        elif "report" in command_lower:
            content = command.replace("report", "").strip()
            return "report", content
        elif "code" in command_lower:
            content = command.replace("code", "").strip()
            return "code", content
        elif "list" in command_lower:
            content = command.replace("list", "").strip()
            return "list", content
        else:
            return "general", command

    def _format_json(self, content: str) -> str:
        """Format content as JSON."""
        try:
            # Try to parse existing JSON
            if content.strip().startswith('{') or content.strip().startswith('['):
                data = json.loads(content)
                formatted = json.dumps(data, indent=2, ensure_ascii=False)
                return f"📋 Formatted JSON:\n\n```json\n{formatted}\n```"
            else:
                # Create JSON structure from text
                lines = [line.strip() for line in content.split('\n') if line.strip()]
                data = {"items": lines, "formatted_at": datetime.now().isoformat()}
                formatted = json.dumps(data, indent=2)
                return f"📋 Generated JSON:\n\n```json\n{formatted}\n```"
        except Exception as e:
            return f"JSON formatting error: {str(e)}"

    def _format_markdown(self, content: str) -> str:
        """Format content as Markdown."""
        lines = content.split('\n')
        formatted_lines = []

        for line in lines:
            line = line.strip()
            if not line:
                formatted_lines.append('')
                continue

            # Auto-detect headers (lines with specific patterns)
            if line.isupper() or (len(line) > 10 and ':' not in line):
                formatted_lines.append(f"## {line}")
            elif ':' in line and len(line.split(':')) == 2:
                key, value = line.split(':', 1)
                formatted_lines.append(f"**{key.strip()}:** {value.strip()}")
            elif line.startswith('-') or line.startswith('*'):
                formatted_lines.append(line)
            else:
                formatted_lines.append(line)

        formatted = '\n'.join(formatted_lines)
        return f"📝 Formatted Markdown:\n\n{formatted}"

    def _format_table(self, content: str) -> str:
        """Format content as a table."""
        lines = [line.strip() for line in content.split('\n') if line.strip()]

        if not lines:
            return "No content to format as table"

        # Detect if content has structured data
        if all(':' in line for line in lines):
            # Key-value pairs
            headers = ["Property", "Value"]
            rows = []
            for line in lines:
                if ':' in line:
                    key, value = line.split(':', 1)
                    rows.append([key.strip(), value.strip()])
        else:
            # Simple list
            headers = ["Item", "Description"]
            rows = [[f"Item {i+1}", line] for i, line in enumerate(lines)]

        # Create markdown table
        table_lines = []
        table_lines.append('| ' + ' | '.join(headers) + ' |')
        table_lines.append('| ' + ' | '.join(['---'] * len(headers)) + ' |')

        for row in rows:
            table_lines.append('| ' + ' | '.join(row) + ' |')

        formatted = '\n'.join(table_lines)
        return f"📊 Formatted Table:\n\n{formatted}"

    def _format_report(self, content: str) -> str:
        """Format content as a structured report."""
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # Structure the content
        lines = [line.strip() for line in content.split('\n') if line.strip()]

        report = f"""# Report
**Generated:** {timestamp}

## Summary
{lines[0] if lines else 'No content provided'}

## Details
"""

        for i, line in enumerate(lines[1:], 1):
            report += f"{i}. {line}\n"

        report += f"""
## Conclusion
Report generated with {len(lines)} items processed.
"""

        return f"📋 Formatted Report:\n\n{report}"

    def _format_code(self, content: str) -> str:
        """Format content as code block."""
        # Detect language
        content_lower = content.lower()
        if 'print(' in content_lower or 'def ' in content_lower:
            language = 'python'
        elif 'function' in content_lower or 'const ' in content_lower:
            language = 'javascript'
        elif '<html>' in content_lower or '<div>' in content_lower:
            language = 'html'
        else:
            language = 'text'

        formatted = f"```{language}\n{content}\n```"
        return f"💻 Formatted Code ({language}):\n\n{formatted}"

    def _format_list(self, content: str) -> str:
        """Format content as a structured list."""
        lines = [line.strip() for line in content.split('\n') if line.strip()]

        formatted_lines = []
        for i, line in enumerate(lines, 1):
            if not line.startswith(('-', '*', str(i))):
                formatted_lines.append(f"{i}. {line}")
            else:
                formatted_lines.append(line)

        formatted = '\n'.join(formatted_lines)
        return f"📝 Formatted List:\n\n{formatted}"

    def _format_general(self, content: str) -> str:
        """General formatting for unspecified content."""
        # Apply basic formatting improvements
        lines = content.split('\n')
        formatted_lines = []

        for line in lines:
            line = line.strip()
            if line:
                # Capitalize sentences
                if line and not line[0].isupper():
                    line = line[0].upper() + line[1:]
                # Ensure proper punctuation
                if line and line[-1] not in '.!?':
                    line += '.'
            formatted_lines.append(line)

        formatted = '\n'.join(formatted_lines)
        return f"✨ General Formatting Applied:\n\n{formatted}"

    def test_connection(self) -> bool:
        """Test if formatting agent is working."""
        test_content = "test item one\ntest item two"
        result = self.execute(f"list {test_content}")
        return "Formatted List" in result

    def get_help(self) -> str:
        """Get help for formatting agent."""
        return """Formatting Agent Help:

Operations:
  • json <content> - Format as JSON
  • markdown <content> - Format as Markdown
  • table <content> - Format as table
  • report <content> - Format as structured report
  • code <content> - Format as code block
  • list <content> - Format as numbered list

Examples:
  "json name: John, age: 30" → JSON format
  "markdown My Title\nSome content" → Markdown format
  "table item1: value1\nitem2: value2" → Table format
  "list apples\nbananas\noranges" → Numbered list

The agent auto-detects content structure and applies appropriate formatting.
"""

if __name__ == "__main__":
    # Test formatting agent
    agent = FormattingAgentTool()

    test_commands = [
        "json name: Test, value: 123",
        "list item one\nitem two\nitem three",
        "markdown My Report\nThis is content"
    ]

    print("✨ Formatting Agent Test:")
    for cmd in test_commands:
        print(f"\n--- {cmd} ---")
        result = agent.execute(cmd)
        print(result[:150] + "..." if len(result) > 150 else result)

    print("\nFormattingAgentTool loaded successfully")
