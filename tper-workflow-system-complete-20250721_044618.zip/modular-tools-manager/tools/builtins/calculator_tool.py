"""
Calculator Tool - Mathematical Computation
Placeholder implementation of Agno's built-in calculator tool.
"""

import re
import math
import operator
from typing import Any, Union

class CalculatorTool:
    def __init__(self):
        """Initialize Calculator Tool."""
        self.name = "calculator"
        self.description = "Performs mathematical calculations and arithmetic operations"
        self.input_format = "string"
        self.output_format = "number"
        self.capabilities = [
            "basic arithmetic (+, -, *, /)",
            "power operations (^, **)",
            "mathematical functions (sin, cos, sqrt, log)",
            "constants (pi, e)",
            "parentheses for grouping"
        ]

        # Define allowed operators and functions
        self.operators = {
            '+': operator.add,
            '-': operator.sub,
            '*': operator.mul,
            '/': operator.truediv,
            '**': operator.pow,
            '^': operator.pow,
            '%': operator.mod
        }

        self.functions = {
            'sin': math.sin,
            'cos': math.cos,
            'tan': math.tan,
            'sqrt': math.sqrt,
            'log': math.log10,
            'ln': math.log,
            'abs': abs,
            'round': round,
            'floor': math.floor,
            'ceil': math.ceil
        }

        self.constants = {
            'pi': math.pi,
            'e': math.e
        }

    def execute(self, expression: str) -> Union[float, int, str]:
        """
        Execute mathematical calculation.

        Args:
            expression: Mathematical expression to evaluate

        Returns:
            Result of the calculation
        """
        try:
            # Clean and prepare expression
            cleaned_expr = self._clean_expression(expression)

            if not cleaned_expr:
                return "Error: Empty expression"

            # Handle simple arithmetic expressions
            if self._is_simple_arithmetic(cleaned_expr):
                result = self._evaluate_simple_arithmetic(cleaned_expr)
            else:
                # Handle complex expressions with functions
                result = self._evaluate_complex_expression(cleaned_expr)

            # Format result
            if isinstance(result, float):
                if result.is_integer():
                    return int(result)
                else:
                    return round(result, 10)  # Avoid floating point precision issues

            return result

        except ZeroDivisionError:
            return "Error: Division by zero"
        except ValueError as e:
            return f"Error: Invalid value - {str(e)}"
        except Exception as e:
            return f"Error: {str(e)}"

    def _clean_expression(self, expression: str) -> str:
        """Clean and normalize the mathematical expression."""
        # Remove whitespace
        cleaned = re.sub(r'\s+', '', expression)

        # Replace common variants
        cleaned = cleaned.replace('^', '**')  # Convert ^ to **
        cleaned = cleaned.replace('x', '*')   # Convert x to * (multiplication)

        # Handle implicit multiplication (e.g., 2pi -> 2*pi)
        cleaned = re.sub(r'(\d+)([a-zA-Z])', r'\1*\2', cleaned)
        cleaned = re.sub(r'([a-zA-Z])(\d+)', r'\1*\2', cleaned)
        cleaned = re.sub(r'\)\(', ')*(', cleaned)
        cleaned = re.sub(r'(\d+)\(', r'\1*(', cleaned)

        return cleaned

    def _is_simple_arithmetic(self, expression: str) -> bool:
        """Check if expression contains only basic arithmetic."""
        # Simple pattern: numbers and basic operators
        simple_pattern = r'^[0-9+\-*/.()\s]+$'
        return bool(re.match(simple_pattern, expression))

    def _evaluate_simple_arithmetic(self, expression: str) -> Union[float, int]:
        """Evaluate simple arithmetic expression safely."""
        # Use eval with restricted namespace for safety
        safe_dict = {
            "__builtins__": {},
            "abs": abs,
            "round": round
        }

        try:
            result = eval(expression, safe_dict)
            return result
        except:
            raise ValueError(f"Cannot evaluate expression: {expression}")

    def _evaluate_complex_expression(self, expression: str) -> Union[float, int]:
        """Evaluate complex expression with functions and constants."""
        # Replace constants
        for const_name, const_value in self.constants.items():
            expression = expression.replace(const_name, str(const_value))

        # Replace function calls
        for func_name, func in self.functions.items():
            pattern = f'{func_name}\(([^)]+)\)'
            matches = re.finditer(pattern, expression)
            for match in matches:
                arg = match.group(1)
                try:
                    arg_value = self._evaluate_simple_arithmetic(arg)
                    result_value = func(arg_value)
                    expression = expression.replace(match.group(0), str(result_value))
                except:
                    raise ValueError(f"Error in function {func_name}({arg})")

        # Evaluate final expression
        return self._evaluate_simple_arithmetic(expression)

    def test_connection(self) -> bool:
        """Test if calculator is working properly."""
        test_expr = "2 + 2"
        result = self.execute(test_expr)
        return result == 4

    def get_help(self) -> str:
        """Get help text for calculator usage."""
        help_text = """Calculator Tool Help:

Basic Operations:
  + : Addition (5 + 3)
  - : Subtraction (10 - 4) 
  * : Multiplication (6 * 7)
  / : Division (15 / 3)
  ** or ^ : Power (2^3 or 2**3)
  % : Modulo (17 % 5)

Functions:
  sin(x), cos(x), tan(x) : Trigonometric functions
  sqrt(x) : Square root
  log(x) : Base 10 logarithm
  ln(x) : Natural logarithm
  abs(x) : Absolute value
  round(x) : Round to nearest integer

Constants:
  pi : 3.14159...
  e : 2.71828...

Examples:
  "15 + 25" → 40
  "sqrt(16) + 2^3" → 12
  "sin(pi/2)" → 1
  "2 * pi * 5" → 31.41592653589793
"""
        return help_text

if __name__ == "__main__":
    # Test the Calculator Tool
    calc = CalculatorTool()

    test_expressions = [
        "15 + 25",
        "10 * 5 - 3",
        "sqrt(16)",
        "2^3",
        "sin(pi/2)",
        "invalid expression"
    ]

    print("🧮 Calculator Tool Test:")
    for expr in test_expressions:
        result = calc.execute(expr)
        print(f"  {expr} = {result}")

    print("\nCalculatorTool loaded successfully")
