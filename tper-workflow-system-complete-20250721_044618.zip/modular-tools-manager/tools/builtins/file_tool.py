"""
File Operations Tool - File System Access
Placeholder implementation of Agno's built-in file operations tool.
"""

import os
import json
from datetime import datetime
from typing import Any, Dict, Union, List

class FileTool:
    def __init__(self):
        """Initialize File Operations Tool."""
        self.name = "file_operations"
        self.description = "Performs file system operations like reading, writing, and managing files"
        self.input_format = "string"
        self.output_format = "string"
        self.capabilities = [
            "file reading and writing",
            "directory operations",
            "text file processing",
            "JSON file handling",
            "file information retrieval",
            "basic file management"
        ]

        # Working directory for file operations (sandboxed)
        self.work_dir = os.path.join(os.getcwd(), "file_workspace")
        self.ensure_work_directory()

        # Allowed file extensions for security
        self.allowed_extensions = {
            '.txt', '.json', '.csv', '.md', '.log', '.data',
            '.py', '.js', '.html', '.css', '.xml', '.yaml', '.yml'
        }

        # Mock files for demonstration
        self.mock_files = {
            "example.txt": "This is an example text file.\nIt contains sample content for demonstration.",
            "data.json": '{"name": "Sample Data", "version": "1.0", "items": [1, 2, 3, 4, 5]}',
            "notes.md": "# Sample Notes\n\nThis is a markdown file with sample content.\n\n## Features\n- File reading\n- File writing\n- Directory operations",
            "config.yaml": "app_name: TPER System\nversion: 2.0\nsettings:\n  debug: true\n  max_iterations: 5"
        }

    def ensure_work_directory(self):
        """Ensure work directory exists."""
        if not os.path.exists(self.work_dir):
            os.makedirs(self.work_dir, exist_ok=True)

    def execute(self, command: str) -> str:
        """
        Execute file operation command.

        Args:
            command: File operation command

        Returns:
            Result of the file operation
        """
        try:
            # Parse command
            operation, params = self._parse_command(command)

            if operation == "read":
                return self._read_file(params.get("filename", ""))
            elif operation == "write":
                return self._write_file(params.get("filename", ""), params.get("content", ""))
            elif operation == "create":
                return self._create_file(params.get("filename", ""), params.get("content", ""))
            elif operation == "list":
                return self._list_files(params.get("directory", "."))
            elif operation == "delete":
                return self._delete_file(params.get("filename", ""))
            elif operation == "info":
                return self._get_file_info(params.get("filename", ""))
            elif operation == "exists":
                return self._check_file_exists(params.get("filename", ""))
            else:
                return self._handle_general_command(command)

        except Exception as e:
            return f"File operation error: {str(e)}"

    def _parse_command(self, command: str) -> tuple:
        """Parse file operation command."""
        command = command.strip().lower()

        # Common command patterns
        if command.startswith("read"):
            filename = command.replace("read", "").strip()
            return "read", {"filename": filename}
        elif command.startswith("write") or command.startswith("save"):
            parts = command.split(" to ")
            if len(parts) == 2:
                content = parts[0].replace("write", "").replace("save", "").strip()
                filename = parts[1].strip()
                return "write", {"filename": filename, "content": content}
        elif command.startswith("create"):
            filename = command.replace("create", "").strip()
            return "create", {"filename": filename, "content": ""}
        elif command.startswith("list"):
            directory = command.replace("list", "").strip() or "."
            return "list", {"directory": directory}
        elif command.startswith("delete"):
            filename = command.replace("delete", "").strip()
            return "delete", {"filename": filename}
        elif command.startswith("info"):
            filename = command.replace("info", "").strip()
            return "info", {"filename": filename}
        elif "exists" in command:
            filename = command.replace("exists", "").replace("check", "").strip()
            return "exists", {"filename": filename}

        return "general", {"command": command}

    def _read_file(self, filename: str) -> str:
        """Read contents of a file."""
        if not filename:
            return "Error: No filename specified"

        # Check if it's a mock file
        if filename in self.mock_files:
            return f"📄 File: {filename}\n\nContent:\n{self.mock_files[filename]}"

        # Try to read real file
        filepath = self._get_safe_path(filename)
        if not filepath:
            return f"Error: Invalid filename '{filename}'"

        try:
            if os.path.exists(filepath):
                with open(filepath, 'r', encoding='utf-8') as f:
                    content = f.read()
                return f"📄 File: {filename}\n\nContent:\n{content}"
            else:
                return f"File '{filename}' not found. Available mock files: {list(self.mock_files.keys())}"
        except Exception as e:
            return f"Error reading file: {str(e)}"

    def _write_file(self, filename: str, content: str) -> str:
        """Write content to a file."""
        if not filename:
            return "Error: No filename specified"

        if not content:
            content = f"File created at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"

        filepath = self._get_safe_path(filename)
        if not filepath:
            return f"Error: Invalid filename '{filename}'"

        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(content)

            file_size = len(content.encode('utf-8'))
            return f"✅ Successfully wrote {file_size} bytes to '{filename}'"

        except Exception as e:
            return f"Error writing file: {str(e)}"

    def _create_file(self, filename: str, content: str = "") -> str:
        """Create a new file."""
        if not filename:
            return "Error: No filename specified"

        filepath = self._get_safe_path(filename)
        if not filepath:
            return f"Error: Invalid filename '{filename}'"

        if os.path.exists(filepath):
            return f"File '{filename}' already exists. Use 'write' to overwrite."

        return self._write_file(filename, content)

    def _list_files(self, directory: str = ".") -> str:
        """List files in directory."""
        if directory == ".":
            # List mock files and workspace files
            files_list = []

            # Mock files
            files_list.append("📂 Mock Files (demo):")
            for filename in sorted(self.mock_files.keys()):
                size = len(self.mock_files[filename])
                files_list.append(f"   📄 {filename} ({size} bytes)")

            # Real workspace files
            files_list.append(f"\n📂 Workspace Files ({self.work_dir}):")
            try:
                if os.path.exists(self.work_dir):
                    workspace_files = os.listdir(self.work_dir)
                    if workspace_files:
                        for filename in sorted(workspace_files):
                            filepath = os.path.join(self.work_dir, filename)
                            if os.path.isfile(filepath):
                                size = os.path.getsize(filepath)
                                files_list.append(f"   📄 {filename} ({size} bytes)")
                    else:
                        files_list.append("   (no files)")
                else:
                    files_list.append("   (workspace not created)")
            except Exception as e:
                files_list.append(f"   Error: {str(e)}")

            return "\n".join(files_list)
        else:
            return f"Directory listing for '{directory}' not supported in demo mode"

    def _delete_file(self, filename: str) -> str:
        """Delete a file."""
        if not filename:
            return "Error: No filename specified"

        if filename in self.mock_files:
            return f"Cannot delete mock file '{filename}' - it's for demonstration only"

        filepath = self._get_safe_path(filename)
        if not filepath:
            return f"Error: Invalid filename '{filename}'"

        try:
            if os.path.exists(filepath):
                os.remove(filepath)
                return f"✅ Successfully deleted '{filename}'"
            else:
                return f"File '{filename}' not found"
        except Exception as e:
            return f"Error deleting file: {str(e)}"

    def _get_file_info(self, filename: str) -> str:
        """Get information about a file."""
        if not filename:
            return "Error: No filename specified"

        # Check mock files
        if filename in self.mock_files:
            content = self.mock_files[filename]
            return f"""📄 File Information: {filename}
Type: Mock file (demo)
Size: {len(content)} characters
Lines: {content.count(chr(10)) + 1}
Content preview: {content[:100]}{'...' if len(content) > 100 else ''}"""

        # Check real files
        filepath = self._get_safe_path(filename)
        if not filepath:
            return f"Error: Invalid filename '{filename}'"

        try:
            if os.path.exists(filepath):
                stat = os.stat(filepath)
                return f"""📄 File Information: {filename}
Type: Regular file
Size: {stat.st_size} bytes
Modified: {datetime.fromtimestamp(stat.st_mtime).strftime('%Y-%m-%d %H:%M:%S')}
Path: {filepath}"""
            else:
                return f"File '{filename}' not found"
        except Exception as e:
            return f"Error getting file info: {str(e)}"

    def _check_file_exists(self, filename: str) -> str:
        """Check if a file exists."""
        if not filename:
            return "Error: No filename specified"

        if filename in self.mock_files:
            return f"✅ Mock file '{filename}' exists"

        filepath = self._get_safe_path(filename)
        if filepath and os.path.exists(filepath):
            return f"✅ File '{filename}' exists in workspace"
        else:
            return f"❌ File '{filename}' does not exist"

    def _handle_general_command(self, command: str) -> str:
        """Handle general file operation commands."""
        if "save" in command and "result" in command:
            # Handle "save result to filename" type commands
            parts = command.split()
            if "to" in parts:
                to_index = parts.index("to")
                if to_index + 1 < len(parts):
                    filename = parts[to_index + 1]
                    content = f"Result saved at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                    return self._write_file(filename, content)

        return f"""File operation '{command}' not recognized.

Available operations:
• read <filename> - Read file contents
• write <content> to <filename> - Write content to file
• create <filename> - Create new file
• list - List available files
• delete <filename> - Delete file
• info <filename> - Get file information
• exists <filename> - Check if file exists

Example: "read example.txt" or "write Hello World to greeting.txt"
"""

    def _get_safe_path(self, filename: str) -> str:
        """Get safe file path within workspace."""
        if not filename:
            return None

        # Remove any path separators for security
        filename = os.path.basename(filename)

        # Check file extension
        _, ext = os.path.splitext(filename)
        if ext.lower() not in self.allowed_extensions:
            return None

        return os.path.join(self.work_dir, filename)

    def test_connection(self) -> bool:
        """Test if file operations are working."""
        test_content = "Test file content"
        test_filename = "test.txt"

        try:
            # Try to write and read
            write_result = self._write_file(test_filename, test_content)
            if "Successfully" not in write_result:
                return False

            read_result = self._read_file(test_filename)
            if test_content not in read_result:
                return False

            # Clean up
            self._delete_file(test_filename)
            return True

        except Exception:
            return False

    def get_help(self) -> str:
        """Get help text for file operations tool."""
        help_text = f"""File Operations Tool Help:

Available Operations:
  • read <filename> - Read file contents
  • write <content> to <filename> - Write content to file  
  • create <filename> - Create new empty file
  • list - List all available files
  • delete <filename> - Delete a file
  • info <filename> - Get file information
  • exists <filename> - Check if file exists

Supported File Types:
  {', '.join(sorted(self.allowed_extensions))}

Working Directory:
  {self.work_dir}

Demo Files Available:
  • example.txt - Sample text file
  • data.json - JSON data file
  • notes.md - Markdown notes
  • config.yaml - YAML configuration

Examples:
  "read example.txt" → Read demo text file
  "write Hello World to greeting.txt" → Create greeting file
  "list" → Show all available files
  "info data.json" → Get JSON file information

Security: Operations restricted to workspace directory only.
"""
        return help_text

if __name__ == "__main__":
    # Test the File Operations Tool
    file_tool = FileTool()

    test_commands = [
        "read example.txt",
        "list",
        "write Test content to test.txt",
        "info example.txt",
        "exists test.txt"
    ]

    print("📁 File Operations Tool Test:")
    for command in test_commands:
        print(f"\n--- Command: {command} ---")
        result = file_tool.execute(command)
        print(result[:200] + "..." if len(result) > 200 else result)

    print("\nFileTool loaded successfully")
