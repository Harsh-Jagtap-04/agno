"""
Python Tool - Code Execution Environment
Placeholder implementation of Agno's built-in Python execution tool.
"""

import sys
import io
import contextlib
import traceback
import ast
import re
from typing import Any, Dict, Union

class PythonTool:
    def __init__(self):
        """Initialize Python Execution Tool."""
        self.name = "python"
        self.description = "Executes Python code in a secure sandbox environment"
        self.input_format = "string"
        self.output_format = "string"
        self.capabilities = [
            "python code execution",
            "mathematical computations",
            "data processing",
            "algorithm implementation",
            "text manipulation",
            "basic data analysis"
        ]

        # Safe built-ins for code execution
        self.safe_builtins = {
            'print': print,
            'len': len,
            'str': str,
            'int': int,
            'float': float,
            'bool': bool,
            'list': list,
            'dict': dict,
            'tuple': tuple,
            'set': set,
            'range': range,
            'enumerate': enumerate,
            'zip': zip,
            'map': map,
            'filter': filter,
            'sum': sum,
            'min': min,
            'max': max,
            'abs': abs,
            'round': round,
            'sorted': sorted,
            'reversed': reversed,
            'any': any,
            'all': all,
            'ord': ord,
            'chr': chr,
            'hex': hex,
            'oct': oct,
            'bin': bin
        }

        # Safe modules that can be imported
        self.safe_modules = {
            'math', 'random', 'datetime', 'json', 're', 'itertools',
            'collections', 'functools', 'operator'
        }

        # Restricted keywords and functions
        self.restricted_keywords = {
            'import', '__import__', 'eval', 'exec', 'compile', 'open',
            'file', 'input', 'raw_input', 'globals', 'locals', 'vars',
            'dir', 'help', 'quit', 'exit'
        }

    def execute(self, code: str) -> str:
        """
        Execute Python code safely.

        Args:
            code: Python code to execute

        Returns:
            Execution result including output and any errors
        """
        try:
            # Clean and validate code
            cleaned_code = self._clean_code(code)

            if not cleaned_code:
                return "Error: Empty code provided"

            # Security check
            if not self._is_code_safe(cleaned_code):
                return "Error: Code contains restricted operations"

            # Execute code
            return self._execute_safe_code(cleaned_code)

        except Exception as e:
            return f"Execution error: {str(e)}"

    def _clean_code(self, code: str) -> str:
        """Clean and prepare code for execution."""
        # Remove common prefixes
        prefixes_to_remove = [
            "python", "execute", "run", "python code:", "```python", "```"
        ]

        cleaned = code.strip()
        for prefix in prefixes_to_remove:
            if cleaned.lower().startswith(prefix):
                cleaned = cleaned[len(prefix):].strip()

        # Remove trailing code block markers
        if cleaned.endswith("```"):
            cleaned = cleaned[:-3].strip()

        # Handle comments and instructions
        lines = cleaned.split('\n')
        code_lines = []

        for line in lines:
            stripped = line.strip()
            # Skip instruction comments
            if stripped.startswith('#') and any(word in stripped.lower() for word in ['calculate', 'compute', 'find', 'solve']):
                # Convert instruction to print statement
                instruction = stripped[1:].strip()
                code_lines.append(f'print("Task: {instruction}")')
            else:
                code_lines.append(line)

        return '\n'.join(code_lines)

    def _is_code_safe(self, code: str) -> bool:
        """Check if code is safe to execute."""
        code_lower = code.lower()

        # Check for restricted keywords
        for keyword in self.restricted_keywords:
            if keyword in code_lower:
                return False

        # Check for file operations
        file_ops = ['open(', 'file(', 'with open', 'os.', 'sys.', 'subprocess']
        if any(op in code_lower for op in file_ops):
            return False

        # Check for network operations
        network_ops = ['urllib', 'requests', 'socket', 'http']
        if any(op in code_lower for op in network_ops):
            return False

        # Try to parse the code
        try:
            ast.parse(code)
            return True
        except SyntaxError:
            return False

    def _execute_safe_code(self, code: str) -> str:
        """Execute code in a restricted environment."""
        # Create safe execution environment
        safe_globals = {
            '__builtins__': self.safe_builtins,
        }

        # Add safe modules
        safe_locals = {}

        # Capture output
        old_stdout = sys.stdout
        old_stderr = sys.stderr

        stdout_capture = io.StringIO()
        stderr_capture = io.StringIO()

        try:
            sys.stdout = stdout_capture
            sys.stderr = stderr_capture

            # Execute the code
            exec(code, safe_globals, safe_locals)

            # Get captured output
            output = stdout_capture.getvalue()
            errors = stderr_capture.getvalue()

            # Restore stdout/stderr
            sys.stdout = old_stdout
            sys.stderr = old_stderr

            # Format result
            result_parts = []

            if output:
                result_parts.append(f"Output:\n{output}")

            if errors:
                result_parts.append(f"Errors:\n{errors}")

            # If no output, try to get the result of the last expression
            if not output and not errors:
                lines = code.strip().split('\n')
                if lines:
                    last_line = lines[-1].strip()
                    if last_line and not last_line.startswith(('print', '#', 'import', 'from')):
                        try:
                            # Try to evaluate the last line as an expression
                            result = eval(last_line, safe_globals, safe_locals)
                            if result is not None:
                                result_parts.append(f"Result: {result}")
                        except:
                            pass

            if not result_parts:
                result_parts.append("Code executed successfully (no output)")

            return '\n\n'.join(result_parts)

        except Exception as e:
            sys.stdout = old_stdout
            sys.stderr = old_stderr

            # Format error with traceback
            error_msg = traceback.format_exc()
            return f"Execution Error:\n{error_msg}"

    def execute_math(self, expression: str) -> str:
        """Execute mathematical expression using Python."""
        math_code = f"""
import math

# Calculate expression
result = {expression}
print(f"Expression: {expression}")
print(f"Result: {{result}}")
"""
        return self.execute(math_code)

    def execute_data_processing(self, data_code: str) -> str:
        """Execute data processing code."""
        processing_code = f"""
# Data processing
{data_code}
"""
        return self.execute(processing_code)

    def test_connection(self) -> bool:
        """Test if Python execution is working."""
        test_code = "print('Python execution test successful')"
        result = self.execute(test_code)
        return "successful" in result and "error" not in result.lower()

    def get_help(self) -> str:
        """Get help text for Python tool usage."""
        help_text = """Python Execution Tool Help:

Supported Operations:
  • Mathematical calculations
  • Data processing and analysis
  • Algorithm implementation
  • String manipulation
  • List/dict operations
  • Control structures (if/for/while)

Available Built-ins:
  • Basic types: int, float, str, bool, list, dict, tuple, set
  • Math functions: sum, min, max, abs, round
  • Iteration: range, enumerate, zip, map, filter
  • Utilities: len, sorted, reversed, any, all

Safe Modules (auto-imported when needed):
  • math: Mathematical functions
  • random: Random number generation
  • datetime: Date/time operations
  • json: JSON processing
  • re: Regular expressions

Security Restrictions:
  • No file system access
  • No network operations
  • No system calls
  • No dangerous built-ins

Examples:
  "print(2 + 3)" → Execute and print calculation
  "sum([1, 2, 3, 4, 5])" → Sum a list
  "[x**2 for x in range(5)]" → List comprehension
  "import math; math.sqrt(16)" → Use math module

Note: Code executes in a restricted sandbox for security.
"""
        return help_text

if __name__ == "__main__":
    # Test the Python Tool
    python_tool = PythonTool()

    test_codes = [
        "print(15 + 25)",
        "result = sum([1, 2, 3, 4, 5])\nprint(f'Sum: {result}')",
        "[x**2 for x in range(5)]",
        "import math\nmath.sqrt(16)",
        "invalid syntax here ("
    ]

    print("🐍 Python Execution Tool Test:")
    for code in test_codes:
        print(f"\n--- Code: {code.replace(chr(10), ' | ')} ---")
        result = python_tool.execute(code)
        print(result)

    print("\nPythonTool loaded successfully")
