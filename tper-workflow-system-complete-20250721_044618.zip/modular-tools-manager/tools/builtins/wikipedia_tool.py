"""
Wikipedia Tool - Encyclopedia Search and Information Retrieval
Placeholder implementation of Agno's built-in Wikipedia search tool.
"""

import json
import re
from datetime import datetime
from typing import Any, Dict, List, Union

class WikipediaTool:
    def __init__(self):
        """Initialize Wikipedia Search Tool."""
        self.name = "wikipedia"
        self.description = "Searches Wikipedia for encyclopedic information and detailed articles"
        self.input_format = "string"
        self.output_format = "string"
        self.capabilities = [
            "encyclopedia search",
            "historical information",
            "biographical data",
            "scientific concepts",
            "detailed article summaries",
            "fact verification"
        ]

        # Mock Wikipedia database for demonstration
        self.mock_articles = {
            "python": {
                "title": "Python (programming language)",
                "summary": "Python is a high-level, interpreted, interactive and object-oriented programming language. Created by Guido van Rossum and first released in 1991, Python's design philosophy emphasizes code readability with its notable use of significant whitespace.",
                "details": "Python supports multiple programming paradigms including procedural, object-oriented, and functional programming. It features a dynamic type system, automatic memory management, and a comprehensive standard library. Python is widely used for web development, data analysis, artificial intelligence, scientific computing, and automation.",
                "category": "Programming Languages"
            },
            "artificial intelligence": {
                "title": "Artificial Intelligence",
                "summary": "Artificial intelligence (AI) is intelligence demonstrated by machines, in contrast to the natural intelligence displayed by humans and animals. AI research has been defined as the field of study of 'intelligent agents': any device that perceives its environment and takes actions that maximize its chance of successfully achieving its goals.",
                "details": "AI applications include advanced web search engines, recommendation systems, understanding human speech, self-driving cars, automated decision-making and competing at the highest level in strategic game systems. As machines become increasingly capable, tasks considered to require intelligence are often removed from the definition of AI, known as the AI effect.",
                "category": "Computer Science"
            },
            "machine learning": {
                "title": "Machine Learning",
                "summary": "Machine learning (ML) is a type of artificial intelligence that allows software applications to become more accurate at predicting outcomes without being explicitly programmed to do so. Machine learning algorithms use historical data as input to predict new output values.",
                "details": "Machine learning is closely related to computational statistics, which focuses on making predictions using computers. The study of mathematical optimization delivers methods, theory and application domains to the field of machine learning. Data mining is a related field of study, focusing on exploratory data analysis through unsupervised learning.",
                "category": "Computer Science"
            },
            "tokyo": {
                "title": "Tokyo",
                "summary": "Tokyo, officially the Tokyo Metropolis, is the capital and most populous prefecture of Japan. Located at the head of Tokyo Bay, the prefecture forms part of the Kantō region on the central Pacific coast of Japan's main island of Honshu.",
                "details": "Tokyo is the political and economic center of the country, as well as the seat of the Emperor of Japan and the national government. The Greater Tokyo Area is the most populous metropolitan area in the world, with more than 37.4 million residents as of 2018. Tokyo hosted the 1964 Summer Olympics and will host the 2020 Summer Olympics (postponed to 2021 due to COVID-19).",
                "category": "Geography"
            },
            "world war ii": {
                "title": "World War II",
                "summary": "World War II (WWII or WW2), also known as the Second World War, was a global war that lasted from 1939 to 1945. It involved the vast majority of the world's countries—including all of the great powers—forming two opposing military alliances: the Allies and the Axis powers.",
                "details": "World War II was the deadliest conflict in human history, marked by 70 to 85 million fatalities. It featured significant events including the Holocaust, the atomic bombings of Hiroshima and Nagasaki, and extensive bombing campaigns. The war ended with the total defeat of the Axis powers in 1945.",
                "category": "History"
            },
            "photosynthesis": {
                "title": "Photosynthesis",
                "summary": "Photosynthesis is a process used by plants and other organisms to convert light energy into chemical energy that, through cellular respiration, can later be released to fuel the organism's metabolic activities.",
                "details": "This chemical energy is stored in carbohydrate molecules, such as sugars, which are synthesized from carbon dioxide and water. In most cases, oxygen is also released as a waste product. Most plants, most algae, and cyanobacteria perform photosynthesis; such organisms are called photoautotrophs.",
                "category": "Biology"
            }
        }

    def execute(self, query: str) -> str:
        """
        Execute Wikipedia search query.

        Args:
            query: Search query for Wikipedia

        Returns:
            Wikipedia article information as formatted string
        """
        try:
            # Clean and normalize query
            cleaned_query = self._clean_query(query)

            if not cleaned_query:
                return "Error: Empty search query"

            # Search mock Wikipedia database
            article = self._search_articles(cleaned_query)

            if article:
                return self._format_article(article)
            else:
                return self._generate_not_found_response(cleaned_query)

        except Exception as e:
            return f"Wikipedia search error: {str(e)}"

    def _clean_query(self, query: str) -> str:
        """Clean and normalize Wikipedia search query."""
        # Remove extra whitespace and common search prefixes
        cleaned = query.strip()

        # Remove common search prefixes
        prefixes_to_remove = [
            "wikipedia", "search wikipedia for", "find on wikipedia",
            "tell me about", "what is", "information about", "article on"
        ]

        cleaned_lower = cleaned.lower()
        for prefix in prefixes_to_remove:
            if cleaned_lower.startswith(prefix):
                cleaned = cleaned[len(prefix):].strip()
                break

        return cleaned

    def _search_articles(self, query: str) -> Dict[str, Any]:
        """Search mock Wikipedia articles for relevant content."""
        query_lower = query.lower()

        # Direct match
        if query_lower in self.mock_articles:
            return self.mock_articles[query_lower]

        # Fuzzy matching
        for key, article in self.mock_articles.items():
            # Check if query matches key words
            if any(word in query_lower for word in key.split()):
                return article

            # Check if query is in title or summary
            title_lower = article["title"].lower()
            summary_lower = article["summary"].lower()

            if (query_lower in title_lower or 
                query_lower in summary_lower or
                any(word in title_lower for word in query_lower.split() if len(word) > 3)):
                return article

        # Check for partial matches in content
        for key, article in self.mock_articles.items():
            details_lower = article["details"].lower()
            query_words = [word for word in query_lower.split() if len(word) > 3]

            matches = sum(1 for word in query_words if word in details_lower)
            if matches >= len(query_words) * 0.5:  # 50% word match
                return article

        return None

    def _format_article(self, article: Dict[str, Any]) -> str:
        """Format Wikipedia article for display."""
        formatted = f"""📖 Wikipedia Article: {article['title']}

Category: {article['category']}

Summary:
{article['summary']}

Details:
{article['details']}

Source: Wikipedia (Simulated)
Retrieved: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}"""

        return formatted

    def _generate_not_found_response(self, query: str) -> str:
        """Generate response when article is not found."""
        return f"""📖 Wikipedia Search: "{query}"

No exact match found in the simulated Wikipedia database.

Suggestions:
• Try rephrasing your search query
• Use more specific or general terms
• Check spelling of key terms
• Consider related topics

Available topics in demo:
• Python (programming language)
• Artificial Intelligence
• Machine Learning
• Tokyo (city)
• World War II
• Photosynthesis

Note: This is a simulated Wikipedia search. The production version would access the full Wikipedia database with millions of articles."""

    def search_summary(self, topic: str) -> str:
        """Get just the summary of a Wikipedia article."""
        article = self._search_articles(topic)
        if article:
            return f"📖 {article['title']} Summary:\n{article['summary']}"
        else:
            return f"No Wikipedia summary found for '{topic}'"

    def search_category(self, category: str) -> List[str]:
        """Search for articles in a specific category."""
        matching_articles = []
        for key, article in self.mock_articles.items():
            if category.lower() in article["category"].lower():
                matching_articles.append(article["title"])

        return matching_articles

    def get_random_article(self) -> str:
        """Get a random Wikipedia article."""
        import random
        random_key = random.choice(list(self.mock_articles.keys()))
        return self._format_article(self.mock_articles[random_key])

    def test_connection(self) -> bool:
        """Test if Wikipedia search is working."""
        test_query = "python"
        result = self.execute(test_query)
        return "Wikipedia Article" in result and "error" not in result.lower()

    def get_help(self) -> str:
        """Get help text for Wikipedia tool usage."""
        help_text = """Wikipedia Search Tool Help:

Search Types:
  • Topic search: "artificial intelligence", "photosynthesis"
  • Historical events: "World War II", "Industrial Revolution"  
  • People: "Albert Einstein", "Marie Curie"
  • Places: "Tokyo", "Mount Everest"
  • Concepts: "machine learning", "quantum physics"

Features:
  • Detailed article summaries
  • Historical and biographical information
  • Scientific and technical concepts
  • Geographic and cultural information
  • Educational content

Examples:
  "Python programming" → Programming language article
  "World War II" → Historical event details
  "Tokyo" → Geographic and cultural information
  "photosynthesis" → Scientific process explanation

Available Demo Topics:
  • Python (programming language)
  • Artificial Intelligence
  • Machine Learning
  • Tokyo
  • World War II
  • Photosynthesis

Note: Demo version has limited articles. Production would access full Wikipedia.
"""
        return help_text

if __name__ == "__main__":
    # Test the Wikipedia Tool
    wiki_tool = WikipediaTool()

    test_queries = [
        "Python programming",
        "artificial intelligence", 
        "Tokyo",
        "photosynthesis",
        "unknown topic"
    ]

    print("📖 Wikipedia Search Tool Test:")
    for query in test_queries:
        print(f"\n--- Query: {query} ---")
        result = wiki_tool.execute(query)
        print(result[:300] + "..." if len(result) > 300 else result)

    print("\nWikipediaTool loaded successfully")
