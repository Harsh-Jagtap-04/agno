"""
Tools Manager - Central Tool Registry and Management
Manages all available tools including built-ins, agents, and MCP servers.
"""

import os
import sys
import importlib
import inspect
from typing import Dict, List, Any, Optional
from datetime import datetime

# Add tools directory to path
tools_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.append(tools_dir)
sys.path.append(os.path.join(tools_dir, 'builtins'))
sys.path.append(os.path.join(tools_dir, 'agents'))
sys.path.append(os.path.join(tools_dir, 'mcp_servers'))

class ToolsManager:
    def __init__(self, config_path: str = None):
        """
        Initialize Tools Manager.

        Args:
            config_path: Path to tools configuration file
        """
        self.tools_registry = {}
        self.enabled_tools = set()
        self.config = self._load_config(config_path)

        # Initialize tools
        self._initialize_builtin_tools()
        self._initialize_agent_tools()
        self._initialize_mcp_servers()

        print(f"✅ Tools Manager initialized with {len(self.tools_registry)} tools")

    def _load_config(self, config_path: str = None) -> Dict[str, Any]:
        """Load tools configuration."""
        default_config = {
            "builtin_tools": {
                "calculator": {"enabled": True},
                "duckduckgo": {"enabled": True},
                "wikipedia": {"enabled": True},
                "python": {"enabled": True},
                "file_operations": {"enabled": True}
            },
            "agent_tools": {
                "formatting_agent": {"enabled": False}
            },
            "mcp_servers": {
                "github_mcp": {"enabled": False}
            }
        }

        if config_path and os.path.exists(config_path):
            try:
                import yaml
                with open(config_path, 'r') as f:
                    config = yaml.safe_load(f)
                return {**default_config, **config}
            except ImportError:
                print("⚠️ PyYAML not installed, using default config")
            except Exception as e:
                print(f"⚠️ Error loading config: {e}, using default config")

        return default_config

    def _initialize_builtin_tools(self):
        """Initialize built-in Agno tools."""
        builtin_tools = {
            'calculator': 'calculator_tool',
            'duckduckgo': 'duckduckgo_tool',
            'wikipedia': 'wikipedia_tool',
            'python': 'python_tool',
            'file_operations': 'file_tool'
        }

        for tool_name, module_name in builtin_tools.items():
            if self.config.get('builtin_tools', {}).get(tool_name, {}).get('enabled', True):
                try:
                    tool_instance = self._load_tool_module(f'builtins.{module_name}', tool_name)
                    if tool_instance:
                        self.tools_registry[tool_name] = tool_instance
                        self.enabled_tools.add(tool_name)
                        print(f"   ✅ Loaded builtin tool: {tool_name}")
                except Exception as e:
                    print(f"   ❌ Failed to load {tool_name}: {e}")

    def _initialize_agent_tools(self):
        """Initialize agent-based tools."""
        agent_tools = {
            'formatting_agent': 'formatting_agent'
        }

        for tool_name, module_name in agent_tools.items():
            if self.config.get('agent_tools', {}).get(tool_name, {}).get('enabled', False):
                try:
                    tool_instance = self._load_tool_module(f'agents.{module_name}', tool_name)
                    if tool_instance:
                        self.tools_registry[tool_name] = tool_instance
                        self.enabled_tools.add(tool_name)
                        print(f"   ✅ Loaded agent tool: {tool_name}")
                except Exception as e:
                    print(f"   ❌ Failed to load agent {tool_name}: {e}")

    def _initialize_mcp_servers(self):
        """Initialize MCP server connections."""
        mcp_servers = {
            'github_mcp': 'github_mcp_server'
        }

        for server_name, module_name in mcp_servers.items():
            if self.config.get('mcp_servers', {}).get(server_name, {}).get('enabled', False):
                try:
                    server_instance = self._load_tool_module(f'mcp_servers.{module_name}', server_name)
                    if server_instance:
                        self.tools_registry[server_name] = server_instance
                        self.enabled_tools.add(server_name)
                        print(f"   ✅ Connected to MCP server: {server_name}")
                except Exception as e:
                    print(f"   ❌ Failed to connect to MCP {server_name}: {e}")

    def _load_tool_module(self, module_path: str, tool_name: str) -> Optional[object]:
        """Load a tool module and return its instance."""
        try:
            # Import the module
            module = importlib.import_module(module_path)

            # Find the tool class (usually capitalized tool name + Tool)
            class_name = self._get_tool_class_name(tool_name)
            tool_class = getattr(module, class_name, None)

            if tool_class and inspect.isclass(tool_class):
                # Create instance of the tool
                return tool_class()
            else:
                print(f"   ⚠️ Tool class {class_name} not found in {module_path}")
                return None

        except ImportError as e:
            print(f"   ⚠️ Could not import {module_path}: {e}")
            return None
        except Exception as e:
            print(f"   ⚠️ Error loading tool {tool_name}: {e}")
            return None

    def _get_tool_class_name(self, tool_name: str) -> str:
        """Generate expected class name for a tool."""
        # Convert tool_name to class name (e.g., 'calculator' -> 'CalculatorTool')
        words = tool_name.replace('_', ' ').split()
        class_name = ''.join(word.capitalize() for word in words) + 'Tool'
        return class_name

    def get_tool(self, tool_name: str) -> Optional[object]:
        """
        Get a tool instance by name.

        Args:
            tool_name: Name of the tool to retrieve

        Returns:
            Tool instance or None if not found
        """
        return self.tools_registry.get(tool_name)

    def get_available_tools(self) -> Dict[str, object]:
        """
        Get all available and enabled tools.

        Returns:
            Dictionary mapping tool names to tool instances
        """
        return {name: tool for name, tool in self.tools_registry.items() 
                if name in self.enabled_tools}

    def get_tool_capabilities(self, tool_name: str) -> Dict[str, Any]:
        """
        Get capabilities information for a specific tool.

        Args:
            tool_name: Name of the tool

        Returns:
            Dictionary containing tool capabilities
        """
        tool = self.get_tool(tool_name)
        if not tool:
            return {}

        capabilities = {
            "name": tool_name,
            "available": tool_name in self.enabled_tools,
            "description": getattr(tool, 'description', 'No description available'),
            "input_format": getattr(tool, 'input_format', 'string'),
            "output_format": getattr(tool, 'output_format', 'string'),
            "capabilities": getattr(tool, 'capabilities', [])
        }

        # Add method information
        if hasattr(tool, 'execute'):
            capabilities["primary_method"] = "execute"

        return capabilities

    def get_tools_status(self) -> Dict[str, Dict[str, Any]]:
        """
        Get status of all tools.

        Returns:
            Dictionary mapping tool names to their status information
        """
        status = {}

        for tool_name, tool in self.tools_registry.items():
            tool_status = {
                "available": tool_name in self.enabled_tools,
                "loaded": tool is not None,
                "type": self._get_tool_type(tool_name),
                "last_checked": datetime.now().isoformat()
            }

            # Test tool availability
            try:
                if hasattr(tool, 'test_connection'):
                    tool.test_connection()
                    tool_status["connection"] = "ok"
                elif hasattr(tool, 'execute'):
                    # Try a simple test
                    tool_status["connection"] = "ok"
                else:
                    tool_status["connection"] = "unknown"
                    tool_status["reason"] = "No test method available"
            except Exception as e:
                tool_status["connection"] = "error"
                tool_status["reason"] = str(e)

            status[tool_name] = tool_status

        return status

    def _get_tool_type(self, tool_name: str) -> str:
        """Determine the type of tool."""
        if tool_name in ['calculator', 'duckduckgo', 'wikipedia', 'python', 'file_operations']:
            return 'builtin'
        elif tool_name.endswith('_agent'):
            return 'agent'
        elif tool_name.endswith('_mcp'):
            return 'mcp_server'
        else:
            return 'unknown'

    def enable_tool(self, tool_name: str) -> bool:
        """
        Enable a specific tool.

        Args:
            tool_name: Name of tool to enable

        Returns:
            True if tool was enabled successfully
        """
        if tool_name in self.tools_registry:
            self.enabled_tools.add(tool_name)
            print(f"✅ Enabled tool: {tool_name}")
            return True
        else:
            print(f"❌ Cannot enable tool {tool_name}: not found in registry")
            return False

    def disable_tool(self, tool_name: str) -> bool:
        """
        Disable a specific tool.

        Args:
            tool_name: Name of tool to disable

        Returns:
            True if tool was disabled successfully
        """
        if tool_name in self.enabled_tools:
            self.enabled_tools.remove(tool_name)
            print(f"⚠️ Disabled tool: {tool_name}")
            return True
        else:
            print(f"⚠️ Tool {tool_name} was not enabled")
            return False

    def reload_tool(self, tool_name: str) -> bool:
        """
        Reload a specific tool.

        Args:
            tool_name: Name of tool to reload

        Returns:
            True if tool was reloaded successfully
        """
        if tool_name in self.tools_registry:
            # Remove from registry
            del self.tools_registry[tool_name]

            # Reload based on tool type
            tool_type = self._get_tool_type(tool_name)

            try:
                if tool_type == 'builtin':
                    self._initialize_builtin_tools()
                elif tool_type == 'agent':
                    self._initialize_agent_tools()
                elif tool_type == 'mcp_server':
                    self._initialize_mcp_servers()

                print(f"🔄 Reloaded tool: {tool_name}")
                return True

            except Exception as e:
                print(f"❌ Failed to reload tool {tool_name}: {e}")
                return False
        else:
            print(f"❌ Cannot reload tool {tool_name}: not found in registry")
            return False

    def list_tools(self) -> Dict[str, Any]:
        """
        Get a formatted list of all tools and their status.

        Returns:
            Dictionary containing tools information
        """
        tools_info = {
            "total_tools": len(self.tools_registry),
            "enabled_tools": len(self.enabled_tools),
            "tools": {}
        }

        for tool_name in sorted(self.tools_registry.keys()):
            capabilities = self.get_tool_capabilities(tool_name)
            tools_info["tools"][tool_name] = {
                "enabled": tool_name in self.enabled_tools,
                "type": self._get_tool_type(tool_name),
                "description": capabilities.get("description", "No description")
            }

        return tools_info

if __name__ == "__main__":
    # Test the Tools Manager
    manager = ToolsManager()

    print("\n📋 Available Tools:")
    tools_list = manager.list_tools()
    for tool_name, info in tools_list["tools"].items():
        status = "✅" if info["enabled"] else "❌"
        print(f"   {status} {tool_name} ({info['type']}): {info['description']}")

    print(f"\nTotal: {tools_list['enabled_tools']}/{tools_list['total_tools']} tools enabled")
    print("\nToolsManager module loaded successfully")
